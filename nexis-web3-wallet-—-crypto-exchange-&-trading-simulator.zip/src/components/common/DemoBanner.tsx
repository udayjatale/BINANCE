import React from 'react';
import { ShieldAlert, RotateCcw, PlusCircle } from 'lucide-react';
import { useWallet } from '../../context/WalletContext';

export const DemoBanner: React.FC = () => {
  const { addFaucetFunds, resetDemoWallet } = useWallet();

  return (
    <div className="bg-[#141824] border-b border-[#2B313A]/80 px-3 py-1.5 flex items-center justify-between text-xs text-slate-300">
      <div className="flex items-center gap-1.5">
        <ShieldAlert className="w-3.5 h-3.5 text-[#F0B90B] shrink-0" />
        <span className="font-bold text-[#F0B90B] tracking-wide text-[11px]">BINANCE WALLET SIMULATOR</span>
        <span className="text-slate-400 hidden sm:inline">·</span>
        <span className="text-slate-400 text-[11px] truncate max-w-[190px] sm:max-w-none">
          Demo mode only — No real crypto
        </span>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={() => addFaucetFunds('USDT', 500)}
          className="flex items-center gap-1 px-2 py-0.5 rounded bg-[#F0B90B]/10 hover:bg-[#F0B90B]/20 text-[#F0B90B] font-semibold text-[11px] transition-colors"
          title="Get +500 Demo USDT"
        >
          <PlusCircle className="w-3 h-3" />
          <span>Faucet</span>
        </button>

        <button
          onClick={() => {
            if (window.confirm('Reset demo wallet back to ₹100,000 starting balance?')) {
              resetDemoWallet();
            }
          }}
          className="flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] transition-colors"
          title="Reset to ₹100,000 default balance"
        >
          <RotateCcw className="w-3 h-3" />
          <span className="hidden xs:inline">Reset</span>
        </button>
      </div>
    </div>
  );
};
