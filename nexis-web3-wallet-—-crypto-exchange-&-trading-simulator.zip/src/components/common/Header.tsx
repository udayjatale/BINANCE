import React, { useState } from 'react';
import { Copy, Check, Info, Activity, Settings } from 'lucide-react';
import { useWallet } from '../../context/WalletContext';

export const Header: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    primaryCurrency,
    setPrimaryCurrency,
    isPriceTicking,
    togglePriceTicking,
    setIsSettingsOpen
  } = useWallet();

  const [copied, setCopied] = useState(false);
  const [showInfo, setShowInfo] = useState(false);

  const demoAddress = '0x8f4c...39a1';

  const copyAddress = () => {
    navigator.clipboard?.writeText('0x8f4c39174b2169da21b0b5e29c11874b39174b2169da21b0b5e29c11874b39a1');
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const isWalletActive = activeTab === 'assets';

  return (
    <>
      <header className="sticky top-0 z-30 bg-[#0B0E14]/95 backdrop-blur-md border-b border-[#1E2329] px-3.5 py-2.5">
        <div className="max-w-4xl mx-auto space-y-2.5">
          {/* Top Row: App Name "BINANCE" + Right Quick Controls */}
          <div className="flex items-center justify-between gap-2">
            {/* App Name BINANCE */}
            <div className="flex items-center gap-2 shrink-0">
              <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-[#181A20] border border-[#2B313A] p-0.5 flex items-center justify-center shrink-0 shadow-sm translate-y-[4px] transition-transform">
                <svg viewBox="0 0 120 120" className="w-5 h-5 fill-[#F0B90B]">
                  {/* Center diamond */}
                  <polygon points="60,45 75,60 60,75 45,60" />
                  {/* Top diamond */}
                  <polygon points="60,15 45,30 53.8,38.8 60,32.6 66.2,38.8 75,30" />
                  {/* Bottom diamond */}
                  <polygon points="60,105 75,90 66.2,81.2 60,87.4 53.8,81.2 45,90" />
                  {/* Left diamond */}
                  <polygon points="15,60 30,75 38.8,66.2 32.6,60 38.8,53.8 30,45" />
                  {/* Right diamond */}
                  <polygon points="105,60 90,45 81.2,53.8 87.4,60 81.2,66.2 90,75" />
                </svg>
              </div>
              <span className="binance-brand-text font-black text-lg sm:text-xl tracking-wider text-[#F0B90B] select-none uppercase drop-shadow-xs">
                BINANCE
              </span>
            </div>

            {/* Controls: Live ticker, Currency INR/USDT, Settings & Info */}
            <div className="flex items-center gap-1.5 shrink-0">
              {/* Live Ticker Pulse */}
              <button
                onClick={togglePriceTicking}
                className={`min-h-[28px] px-2 rounded-lg text-xs font-medium flex items-center gap-1 transition-colors ${
                  isPriceTicking
                    ? 'text-[#0ECB81] bg-[#0ECB81]/10 hover:bg-[#0ECB81]/20'
                    : 'text-slate-400 bg-slate-800/80 hover:bg-slate-800'
                }`}
                title={isPriceTicking ? 'Live Prices ON' : 'Price Updates Paused'}
              >
                <Activity className="w-3.5 h-3.5" />
                <span className="hidden sm:inline text-[11px]">{isPriceTicking ? 'Live' : 'Paused'}</span>
              </button>

              {/* Currency INR / USDT Switcher */}
              <div className="flex items-center bg-[#181A20] p-0.5 rounded-lg border border-slate-800 text-xs">
                <button
                  onClick={() => setPrimaryCurrency('INR')}
                  className={`px-2 py-0.5 rounded-md font-semibold text-xs transition-all ${
                    primaryCurrency === 'INR'
                      ? 'bg-[#F0B90B] text-black shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  ₹ INR
                </button>
                <button
                  onClick={() => setPrimaryCurrency('USDT')}
                  className={`px-2 py-0.5 rounded-md font-semibold text-xs transition-all ${
                    primaryCurrency === 'USDT'
                      ? 'bg-[#F0B90B] text-black shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  $ USDT
                </button>
              </div>

              {/* Settings Modal Trigger (Appearance/Theme, Currency, Live Ticks) */}
              <button
                onClick={() => setIsSettingsOpen(true)}
                className="w-7 h-7 flex items-center justify-center rounded-lg bg-[#181A20] hover:bg-[#2B313A] text-slate-300 hover:text-white transition-colors"
                aria-label="Settings and Theme"
                title="Settings & Appearance"
              >
                <Settings className="w-3.5 h-3.5" />
              </button>

              {/* Info modal trigger */}
              <button
                onClick={() => setShowInfo(true)}
                className="w-7 h-7 flex items-center justify-center rounded-lg bg-[#181A20] hover:bg-[#2B313A] text-slate-300 hover:text-white transition-colors"
                aria-label="Simulation info"
                title="Simulation Information"
              >
                <Info className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Sub Row: [ Exchange | Wallet ] Section + Address 0x8f4c...39a1 */}
          <div className="flex items-center justify-between gap-2 pt-1 border-t border-[#1E2329]/60">
            {/* Mode Switcher: [ Exchange | Wallet ] */}
            <div className="flex items-center bg-[#181A20] p-0.5 rounded-lg border border-slate-800 text-xs">
              <button
                onClick={() => {
                  if (activeTab === 'assets') {
                    setActiveTab('home');
                  }
                }}
                className={`px-3 py-1 rounded-md font-bold text-[11px] transition-all ${
                  !isWalletActive
                    ? 'bg-[#2B313A] text-white shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Exchange
              </button>
              <button
                onClick={() => {
                  setActiveTab('assets');
                }}
                className={`px-3 py-1 rounded-md font-bold text-[11px] transition-all flex items-center gap-1 ${
                  isWalletActive
                    ? 'bg-[#F0B90B] text-black shadow-xs font-black'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <span>Wallet</span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              </button>
            </div>

            {/* Quick address chip */}
            <button
              onClick={copyAddress}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#181A20] hover:bg-[#2B313A] text-slate-300 text-xs font-mono transition-colors border border-slate-800"
              title="Click to copy simulated address"
            >
              <span>{demoAddress}</span>
              {copied ? <Check className="w-3.5 h-3.5 text-[#0ECB81]" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
            </button>
          </div>
        </div>
      </header>

      {/* Info Modal */}
      {showInfo && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#181A20] border border-[#2B313A] rounded-2xl p-5 max-w-sm w-full text-slate-200 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#2B313A]">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded bg-[#F0B90B] flex items-center justify-center text-black font-black text-xs">
                  B
                </div>
                <h3 className="font-bold text-white text-base">Binance Web3 Wallet (Demo)</h3>
              </div>
              <button
                onClick={() => setShowInfo(false)}
                className="text-slate-400 hover:text-white text-sm px-2 py-1"
              >
                ✕
              </button>
            </div>

            <div className="py-4 space-y-3 text-xs leading-relaxed text-slate-300">
              <div className="p-3 rounded-xl bg-[#0B0E14] border border-[#2B313A]">
                <p className="font-semibold text-[#F0B90B] mb-1">Educational Simulator</p>
                <p className="text-slate-400">
                  This application simulates the Binance Web3 Wallet interface. All balances, tokens (BTC, ETH, BNB, SOL, etc.), swaps, and charts are purely simulated dummy test data.
                </p>
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Starting Portfolio:</span>
                  <span className="font-medium text-white">₹100,000 (~$1,156 USDT)</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Exchange Rate:</span>
                  <span className="font-medium text-white">1 USDT = ₹86.50 INR</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Network:</span>
                  <span className="font-medium text-[#0ECB81]">BNB Smart Chain (Simulation)</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => setShowInfo(false)}
              className="w-full py-2.5 rounded-xl bg-[#F0B90B] hover:bg-[#FCD535] text-black font-bold text-xs transition-colors"
            >
              Continue Demo
            </button>
          </div>
        </div>
      )}
    </>
  );
};
