import React, { useState, useMemo, useRef } from 'react';
import { generateChartData } from '../../data/mockTokens';

interface InteractiveChartProps {
  basePrice: number;
  symbol: string;
  isPositive: boolean;
  currencySymbol: string;
  currencyRate: number; // 1 for USD, 86.50 for INR
}

type Timeframe = '1D' | '1W' | '1M' | '1Y' | 'ALL';
type ChartMode = 'line' | 'candle';

export const InteractiveChart: React.FC<InteractiveChartProps> = ({
  basePrice,
  symbol,
  isPositive,
  currencySymbol,
  currencyRate
}) => {
  const [timeframe, setTimeframe] = useState<Timeframe>('1D');
  const [chartMode, setChartMode] = useState<ChartMode>('line');
  const [hoverPoint, setHoverPoint] = useState<{
    price: number;
    timestamp: number;
    x: number;
  } | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);

  // Generate deterministic/smooth data for current timeframe
  const chartData = useMemo(() => {
    return generateChartData(basePrice, timeframe);
  }, [basePrice, timeframe]);

  const prices = chartData.map(d => d.price);
  const minPrice = Math.min(...prices);
  const maxPrice = Math.max(...prices);
  const priceRange = maxPrice - minPrice || 1;

  // Sizing
  const svgWidth = 360;
  const svgHeight = 200;
  const chartTopPadding = 20;
  const chartBottomPadding = 35;
  const usableHeight = svgHeight - chartTopPadding - chartBottomPadding;

  // Path generation
  const linePoints = useMemo(() => {
    return chartData.map((d, i) => {
      const x = (i / (chartData.length - 1)) * svgWidth;
      const y = chartTopPadding + usableHeight - ((d.price - minPrice) / priceRange) * usableHeight;
      return { x, y, data: d };
    });
  }, [chartData, minPrice, priceRange, usableHeight]);

  const pathD = useMemo(() => {
    if (linePoints.length === 0) return '';
    return linePoints.reduce((acc, curr, idx) => {
      return idx === 0 ? `M ${curr.x},${curr.y}` : `${acc} L ${curr.x},${curr.y}`;
    }, '');
  }, [linePoints]);

  const areaD = useMemo(() => {
    if (linePoints.length === 0) return '';
    const firstX = linePoints[0].x;
    const lastX = linePoints[linePoints.length - 1].x;
    const bottomY = chartTopPadding + usableHeight;
    return `${pathD} L ${lastX},${bottomY} L ${firstX},${bottomY} Z`;
  }, [pathD, linePoints, chartTopPadding, usableHeight]);

  const strokeColor = isPositive ? '#0ECB81' : '#F6465D';
  const gradientId = `chart-grad-${symbol}-${isPositive ? 'green' : 'red'}`;

  // Scrub handler
  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const clientX = e.clientX - rect.left;
    const clampedX = Math.max(0, Math.min(rect.width, clientX));
    const ratio = clampedX / rect.width;
    const idx = Math.min(
      chartData.length - 1,
      Math.max(0, Math.round(ratio * (chartData.length - 1)))
    );

    const point = chartData[idx];
    setHoverPoint({
      price: point.price,
      timestamp: point.timestamp,
      x: (idx / (chartData.length - 1)) * svgWidth
    });
  };

  const handlePointerLeave = () => {
    setHoverPoint(null);
  };

  const displayedPrice = hoverPoint ? hoverPoint.price : basePrice;
  const formattedPrice = (displayedPrice * currencyRate).toLocaleString(undefined, {
    minimumFractionDigits: displayedPrice < 1 ? 4 : 2,
    maximumFractionDigits: displayedPrice < 1 ? 6 : 2
  });

  const formattedDate = hoverPoint
    ? new Date(hoverPoint.timestamp).toLocaleString(undefined, {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      })
    : `${timeframe} Price Trend`;

  const timeframes: Timeframe[] = ['1D', '1W', '1M', '1Y', 'ALL'];

  return (
    <div className="w-full flex flex-col">
      {/* Price Header inside Chart */}
      <div className="flex items-baseline justify-between mb-2 px-1">
        <div>
          <div className="text-2xl font-bold font-mono tracking-tight text-white">
            {currencySymbol}{formattedPrice}
          </div>
          <div className="text-xs text-slate-400 font-mono mt-0.5">
            {formattedDate}
          </div>
        </div>

        {/* Mode Toggle (Line vs Candle) */}
        <div className="flex items-center gap-1 bg-[#181A20] p-1 rounded-lg border border-slate-800">
          <button
            onClick={() => setChartMode('line')}
            className={`px-2 py-0.5 text-xs font-semibold rounded ${
              chartMode === 'line'
                ? 'bg-slate-700 text-white shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Line
          </button>
          <button
            onClick={() => setChartMode('candle')}
            className={`px-2 py-0.5 text-xs font-semibold rounded ${
              chartMode === 'candle'
                ? 'bg-slate-700 text-white shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Candles
          </button>
        </div>
      </div>

      {/* Interactive Chart Canvas Container */}
      <div
        ref={containerRef}
        onPointerMove={handlePointerMove}
        onPointerLeave={handlePointerLeave}
        className="relative w-full h-[200px] select-none touch-none cursor-crosshair bg-[#12161F]/60 rounded-xl p-2 border border-slate-800/80"
      >
        <svg
          viewBox={`0 0 ${svgWidth} ${svgHeight}`}
          className="w-full h-full overflow-visible"
          preserveAspectRatio="none"
        >
          <defs>
            <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={strokeColor} stopOpacity="0.28" />
              <stop offset="100%" stopColor={strokeColor} stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Grid lines */}
          <line
            x1="0"
            y1={chartTopPadding}
            x2={svgWidth}
            y2={chartTopPadding}
            stroke="#2B313A"
            strokeDasharray="3 3"
            strokeWidth="0.8"
          />
          <line
            x1="0"
            y1={chartTopPadding + usableHeight / 2}
            x2={svgWidth}
            y2={chartTopPadding + usableHeight / 2}
            stroke="#2B313A"
            strokeDasharray="3 3"
            strokeWidth="0.8"
          />
          <line
            x1="0"
            y1={chartTopPadding + usableHeight}
            x2={svgWidth}
            y2={chartTopPadding + usableHeight}
            stroke="#2B313A"
            strokeDasharray="3 3"
            strokeWidth="0.8"
          />

          {/* Candlestick or Line rendering */}
          {chartMode === 'line' ? (
            <>
              {/* Area gradient fill */}
              <path d={areaD} fill={`url(#${gradientId})`} />
              {/* Line */}
              <path
                d={pathD}
                fill="none"
                stroke={strokeColor}
                strokeWidth="2.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </>
          ) : (
            /* Candlestick mode */
            chartData.map((candle, idx) => {
              const x = (idx / (chartData.length - 1)) * svgWidth;
              const candleW = Math.max(3, svgWidth / (chartData.length * 1.6));
              const isGreen = candle.close >= candle.open;
              const color = isGreen ? '#0ECB81' : '#F6465D';

              const highY = chartTopPadding + usableHeight - ((candle.high - minPrice) / priceRange) * usableHeight;
              const lowY = chartTopPadding + usableHeight - ((candle.low - minPrice) / priceRange) * usableHeight;
              const openY = chartTopPadding + usableHeight - ((candle.open - minPrice) / priceRange) * usableHeight;
              const closeY = chartTopPadding + usableHeight - ((candle.close - minPrice) / priceRange) * usableHeight;

              const bodyTop = Math.min(openY, closeY);
              const bodyHeight = Math.max(2, Math.abs(openY - closeY));

              return (
                <g key={idx}>
                  {/* Wick */}
                  <line
                    x1={x}
                    y1={highY}
                    x2={x}
                    y2={lowY}
                    stroke={color}
                    strokeWidth="1.2"
                  />
                  {/* Body */}
                  <rect
                    x={x - candleW / 2}
                    y={bodyTop}
                    width={candleW}
                    height={bodyHeight}
                    fill={color}
                    rx="1"
                  />
                </g>
              );
            })
          )}

          {/* Volume bars at bottom */}
          {chartData.map((d, i) => {
            const x = (i / (chartData.length - 1)) * svgWidth;
            const barW = Math.max(2, svgWidth / (chartData.length * 2.2));
            const volMax = Math.max(...chartData.map(c => c.volume)) || 1;
            const barH = (d.volume / volMax) * 22;
            const y = svgHeight - barH;
            return (
              <rect
                key={i}
                x={x - barW / 2}
                y={y}
                width={barW}
                height={barH}
                fill="#344054"
                opacity="0.45"
                rx="0.5"
              />
            );
          })}

          {/* Hover Crosshair indicator */}
          {hoverPoint && (
            <g>
              <line
                x1={hoverPoint.x}
                y1={0}
                x2={hoverPoint.x}
                y2={svgHeight}
                stroke="#F0B90B"
                strokeWidth="1.2"
                strokeDasharray="2 2"
              />
              <circle
                cx={hoverPoint.x}
                cy={
                  chartTopPadding +
                  usableHeight -
                  ((hoverPoint.price - minPrice) / priceRange) * usableHeight
                }
                r="4.5"
                fill="#F0B90B"
                stroke="#0B0E14"
                strokeWidth="2"
              />
            </g>
          )}
        </svg>

        {/* High / Low markers */}
        <div className="absolute right-2 top-2 text-[10px] font-mono text-slate-400">
          H: {currencySymbol}{(maxPrice * currencyRate).toFixed(maxPrice < 1 ? 4 : 2)}
        </div>
        <div className="absolute right-2 bottom-8 text-[10px] font-mono text-slate-400">
          L: {currencySymbol}{(minPrice * currencyRate).toFixed(minPrice < 1 ? 4 : 2)}
        </div>
      </div>

      {/* Timeframe Selector Buttons */}
      <div className="flex items-center justify-between gap-1 mt-3 px-1">
        {timeframes.map(tf => {
          const isSelected = timeframe === tf;
          return (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                isSelected
                  ? 'bg-[#F0B90B]/15 text-[#F0B90B] border border-[#F0B90B]/30'
                  : 'text-slate-400 hover:text-white bg-[#181A20] border border-transparent'
              }`}
            >
              {tf}
            </button>
          );
        })}
      </div>
    </div>
  );
};
