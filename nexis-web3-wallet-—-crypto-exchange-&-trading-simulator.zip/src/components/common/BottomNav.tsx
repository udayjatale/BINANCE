import React from 'react';
import { Home, BarChart2, ArrowLeftRight, Compass, Wallet } from 'lucide-react';
import { useWallet } from '../../context/WalletContext';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab } = useWallet();

  const navItems = [
    { id: 'home' as const, label: 'Home', icon: Home },
    { id: 'markets' as const, label: 'Markets', icon: BarChart2 },
    { id: 'trade' as const, label: 'Trade', icon: ArrowLeftRight },
    { id: 'discover' as const, label: 'Discover', icon: Compass },
    { id: 'assets' as const, label: 'Assets', icon: Wallet }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#0B0E14]/95 backdrop-blur-lg border-t border-[#1E2329] pb-[env(safe-area-inset-bottom,0px)]">
      <div className="max-w-md mx-auto grid grid-cols-5 h-16 items-center px-1">
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center justify-center min-h-[48px] py-1 transition-colors relative ${
                isActive ? 'text-[#F0B90B]' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-transform duration-150 ${
                    isActive ? 'scale-110' : ''
                  }`}
                  strokeWidth={isActive ? 2.3 : 1.8}
                />
                {isActive && (
                  <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-[#F0B90B]" />
                )}
              </div>
              <span
                className={`text-[11px] font-medium tracking-tight mt-1 ${
                  isActive ? 'text-[#F0B90B] font-semibold' : 'text-slate-400'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
