import React, { useState } from 'react';
import { TrendingUp, TrendingDown, ShieldAlert, X, AlertTriangle } from 'lucide-react';
import { useWallet } from '../../context/WalletContext';

export const PerpsTab: React.FC = () => {
  const {
    tokens,
    holdings,
    perpPositions,
    openPerpPosition,
    closePerpPosition,
    primaryCurrency
  } = useWallet();

  const [selectedPair, setSelectedPair] = useState<string>('BTC/USDT');
  const [side, setSide] = useState<'long' | 'short'>('long');
  const [leverage, setLeverage] = useState<number>(10);
  const [marginUsd, setMarginUsd] = useState<string>('50');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const baseSymbol = selectedPair.split('/')[0];
  const token = tokens.find(t => t.symbol === baseSymbol) || tokens[0];
  const currentPrice = token.priceUsd;
  const usdtBalance = holdings['USDT'] || 0;

  const parsedMargin = parseFloat(marginUsd) || 0;
  const notionalSize = parsedMargin * leverage;
  const tokenSize = currentPrice > 0 ? notionalSize / currentPrice : 0;

  // Liquidation price calculation
  const buffer = 0.90 / leverage;
  const estLiqPrice = side === 'long'
    ? currentPrice * (1 - buffer)
    : currentPrice * (1 + buffer);

  const leverageOptions = [2, 5, 10, 20, 50];

  const handleOpenTrade = () => {
    setErrorMsg(null);
    if (parsedMargin <= 0) {
      setErrorMsg('Enter a valid margin amount.');
      return;
    }
    if (usdtBalance < parsedMargin) {
      setErrorMsg(`Insufficient USDT margin. Available: $${usdtBalance.toFixed(2)}`);
      return;
    }

    const res = openPerpPosition(selectedPair, side, leverage, parsedMargin);
    if (!res.success) {
      setErrorMsg(res.error || 'Failed to open position.');
    } else {
      setMarginUsd('50');
    }
  };

  return (
    <div className="space-y-4">
      {/* High-Risk Disclaimer */}
      <div className="p-2.5 rounded-xl bg-[#F0B90B]/10 border border-[#F0B90B]/20 flex items-center gap-2 text-xs text-[#F0B90B]">
        <AlertTriangle className="w-4 h-4 shrink-0" />
        <span>
          Perpetual contracts demo. Leverage multiplies virtual gains & losses. Educational simulation only.
        </span>
      </div>

      {/* Main Perps Box */}
      <div className="bg-[#181A20] border border-[#2B313A] rounded-2xl p-4 space-y-4 shadow-lg">
        {/* Pair & Price Header */}
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <select
              value={selectedPair}
              onChange={e => setSelectedPair(e.target.value)}
              className="bg-[#12161F] text-white font-bold text-sm px-2.5 py-1 rounded-lg border border-slate-700 focus:outline-none cursor-pointer"
            >
              <option value="BTC/USDT">BTC/USDT Perp</option>
              <option value="BNB/USDT">BNB/USDT Perp</option>
              <option value="ETH/USDT">ETH/USDT Perp</option>
              <option value="SOL/USDT">SOL/USDT Perp</option>
            </select>
            <div className="font-mono text-white font-bold text-sm">
              ${currentPrice.toFixed(currentPrice < 1 ? 4 : 2)}
            </div>
          </div>

          <span className="text-[10px] font-semibold text-slate-400 font-mono">
            Funding: 0.0100% / 8h
          </span>
        </div>

        {/* Long vs Short Buttons */}
        <div className="grid grid-cols-2 gap-2 bg-[#12161F] p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => setSide('long')}
            className={`py-2 rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 transition-colors ${
              side === 'long'
                ? 'bg-[#0ECB81] text-black shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            <span>Open Long (Bull)</span>
          </button>
          <button
            onClick={() => setSide('short')}
            className={`py-2 rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 transition-colors ${
              side === 'short'
                ? 'bg-[#F6465D] text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <TrendingDown className="w-4 h-4" />
            <span>Open Short (Bear)</span>
          </button>
        </div>

        {/* Leverage Selector */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-xs text-slate-400">
            <span>Select Leverage</span>
            <span className="font-bold text-[#F0B90B] font-mono">{leverage}x</span>
          </div>

          <div className="grid grid-cols-5 gap-1.5">
            {leverageOptions.map(l => (
              <button
                key={l}
                onClick={() => setLeverage(l)}
                className={`py-1.5 rounded-lg font-bold text-xs font-mono transition-colors ${
                  leverage === l
                    ? 'bg-[#F0B90B] text-black'
                    : 'bg-[#12161F] text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {l}x
              </button>
            ))}
          </div>
        </div>

        {/* Margin Amount Input */}
        <div className="bg-[#12161F] border border-slate-800 rounded-xl p-3 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Margin (USDT)</span>
            <div className="flex items-center gap-1">
              <span>Available:</span>
              <button
                onClick={() => setMarginUsd(usdtBalance.toFixed(2))}
                className="font-mono text-slate-200 hover:text-[#F0B90B] underline font-semibold"
              >
                ${usdtBalance.toFixed(2)}
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="number"
              value={marginUsd}
              onChange={e => setMarginUsd(e.target.value)}
              placeholder="0.00"
              className="w-full bg-transparent text-xl font-bold font-mono text-white focus:outline-none"
            />
            <span className="text-xs font-bold text-slate-400">USDT</span>
          </div>

          {/* Shortcuts */}
          <div className="flex justify-end gap-1 pt-1">
            {[25, 50, 75, 100].map(pct => (
              <button
                key={pct}
                onClick={() => setMarginUsd(((usdtBalance * pct) / 100).toFixed(2))}
                className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300"
              >
                {pct}%
              </button>
            ))}
          </div>
        </div>

        {/* Order Details Preview */}
        <div className="p-3 rounded-xl bg-[#12161F]/60 border border-slate-800 text-xs text-slate-400 space-y-1.5 font-mono">
          <div className="flex justify-between">
            <span>Position Size:</span>
            <span className="text-white font-semibold">
              ${notionalSize.toFixed(2)} ({tokenSize.toFixed(4)} {baseSymbol})
            </span>
          </div>
          <div className="flex justify-between">
            <span>Entry Mark Price:</span>
            <span className="text-slate-300">${currentPrice.toFixed(2)}</span>
          </div>
          <div className="flex justify-between">
            <span>Est. Liquidation Price:</span>
            <span className="text-[#F6465D] font-bold">${estLiqPrice.toFixed(2)}</span>
          </div>
        </div>

        {errorMsg && (
          <div className="p-2.5 rounded-lg bg-red-950/40 border border-red-800 text-red-300 text-xs">
            {errorMsg}
          </div>
        )}

        <button
          onClick={handleOpenTrade}
          className={`w-full py-3.5 rounded-xl font-bold text-xs transition-colors shadow-md ${
            side === 'long'
              ? 'bg-[#0ECB81] hover:bg-[#02C076] text-black'
              : 'bg-[#F6465D] hover:bg-[#E03149] text-white'
          }`}
        >
          Open {leverage}x {side.toUpperCase()} Demo Position
        </button>
      </div>

      {/* Active Perp Positions Section */}
      <div className="space-y-2">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 px-1">
          Open Positions ({perpPositions.length})
        </h4>

        {perpPositions.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500 bg-[#181A20] rounded-xl border border-slate-800">
            No active futures positions. Open a simulated Long or Short position above.
          </div>
        ) : (
          <div className="space-y-2">
            {perpPositions.map(pos => {
              const base = pos.symbol.split('/')[0];
              const t = tokens.find(tok => tok.symbol === base);
              const mark = t ? t.priceUsd : pos.entryPrice;

              const delta = (mark - pos.entryPrice) / pos.entryPrice;
              const roePct = (pos.side === 'long' ? delta : -delta) * pos.leverage * 100;
              const pnlUsd = (pos.marginUsd * roePct) / 100;
              const isProfit = pnlUsd >= 0;

              return (
                <div
                  key={pos.id}
                  className="bg-[#181A20] border border-[#2B313A] rounded-xl p-3 space-y-2 shadow-sm"
                >
                  <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[10px] font-bold px-1.5 py-0.2 rounded uppercase ${
                          pos.side === 'long' ? 'bg-[#0ECB81]/15 text-[#0ECB81]' : 'bg-[#F6465D]/15 text-[#F6465D]'
                        }`}
                      >
                        {pos.side} {pos.leverage}x
                      </span>
                      <span className="font-bold text-xs text-white">{pos.symbol}</span>
                    </div>

                    <button
                      onClick={() => closePerpPosition(pos.id)}
                      className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-[11px] transition-colors"
                    >
                      Close Market
                    </button>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-xs font-mono">
                    <div>
                      <span className="text-[10px] text-slate-400 block">Unrealized PnL</span>
                      <span className={`font-bold ${isProfit ? 'text-[#0ECB81]' : 'text-[#F6465D]'}`}>
                        {isProfit ? '+' : ''}${pnlUsd.toFixed(2)} ({isProfit ? '+' : ''}{roePct.toFixed(2)}%)
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block">Entry Price</span>
                      <span className="text-slate-300">${pos.entryPrice.toFixed(2)}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block">Mark Price</span>
                      <span className="text-slate-300">${mark.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
