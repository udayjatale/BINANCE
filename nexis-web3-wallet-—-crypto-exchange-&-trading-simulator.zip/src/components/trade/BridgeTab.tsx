import React, { useState } from 'react';
import { ArrowRight, Layers, CheckCircle, Clock, AlertCircle } from 'lucide-react';
import { useWallet } from '../../context/WalletContext';

export const BridgeTab: React.FC = () => {
  const { holdings, executeDeposit, executeWithdraw, tokens } = useWallet();

  const chains = [
    { id: 'bsc', name: 'BNB Smart Chain', icon: '🔶' },
    { id: 'eth', name: 'Ethereum Mainnet', icon: '⟠' },
    { id: 'sol', name: 'Solana Network', icon: '◎' },
    { id: 'arb', name: 'Arbitrum One', icon: '🔵' },
    { id: 'poly', name: 'Polygon PoS', icon: '🟣' },
    { id: 'base', name: 'Base Network', icon: '🔵' }
  ];

  const [fromChain, setFromChain] = useState(chains[0].id);
  const [toChain, setToChain] = useState(chains[1].id);
  const [tokenSymbol, setTokenSymbol] = useState('USDT');
  const [amount, setAmount] = useState('50');
  const [isBridging, setIsBridging] = useState(false);
  const [bridgeStep, setBridgeStep] = useState<number>(0);
  const [completed, setCompleted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const balance = holdings[tokenSymbol] || 0;
  const parsedAmount = parseFloat(amount) || 0;

  const handleStartBridge = () => {
    setError(null);
    if (parsedAmount <= 0) {
      setError('Please enter an amount greater than 0.');
      return;
    }
    if (balance < parsedAmount) {
      setError(`Insufficient ${tokenSymbol} balance. Available: ${balance.toFixed(2)}`);
      return;
    }
    if (fromChain === toChain) {
      setError('Source and Destination chains must be different.');
      return;
    }

    setIsBridging(true);
    setBridgeStep(1);

    // Step 1: Locking
    setTimeout(() => {
      setBridgeStep(2);
      // Step 2: Relaying
      setTimeout(() => {
        setBridgeStep(3);
        // Step 3: Finalized
        setTimeout(() => {
          setIsBridging(false);
          setCompleted(true);
          setBridgeStep(4);
          // Log simulated bridge tx
          executeWithdraw(
            tokenSymbol,
            parsedAmount,
            '0x8f4c...39a1',
            `Bridge: ${fromChain.toUpperCase()} → ${toChain.toUpperCase()}`
          );
        }, 1200);
      }, 1400);
    }, 1200);
  };

  const resetForm = () => {
    setCompleted(false);
    setBridgeStep(0);
    setAmount('50');
  };

  const fromChainObj = chains.find(c => c.id === fromChain)!;
  const toChainObj = chains.find(c => c.id === toChain)!;

  return (
    <div className="bg-[#181A20] border border-[#2B313A] rounded-2xl p-4 shadow-lg space-y-4">
      <div className="flex items-center justify-between pb-2 border-b border-slate-800">
        <div>
          <h3 className="font-bold text-white text-sm">Cross-Chain Bridge Demo</h3>
          <p className="text-[11px] text-slate-400">Simulate cross-network liquidity transfers</p>
        </div>
        <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-[#F0B90B]/10 text-[#F0B90B]">
          Virtual Relayer
        </span>
      </div>

      {completed ? (
        <div className="py-8 text-center space-y-3">
          <div className="w-14 h-14 rounded-full bg-[#0ECB81]/15 text-[#0ECB81] flex items-center justify-center mx-auto">
            <CheckCircle className="w-8 h-8" />
          </div>
          <h4 className="font-bold text-white text-base">Bridge Transfer Complete!</h4>
          <p className="text-xs text-slate-400 max-w-xs mx-auto">
            Simulated {parsedAmount} {tokenSymbol} successfully bridged from {fromChainObj.name} to {toChainObj.name}.
          </p>
          <button
            onClick={resetForm}
            className="px-6 py-2 rounded-xl bg-[#F0B90B] text-black font-semibold text-xs transition-colors"
          >
            Bridge Another Token
          </button>
        </div>
      ) : isBridging ? (
        /* Progress simulation */
        <div className="py-8 space-y-5 text-center">
          <div className="w-12 h-12 rounded-full border-2 border-[#F0B90B] border-t-transparent animate-spin mx-auto" />
          <div>
            <h4 className="font-bold text-white text-sm">Bridging In Progress...</h4>
            <p className="text-xs text-slate-400 mt-1">Please wait while the simulated relayer confirms.</p>
          </div>

          <div className="max-w-xs mx-auto space-y-2 text-left text-xs">
            <div className={`flex items-center gap-2 ${bridgeStep >= 1 ? 'text-[#0ECB81]' : 'text-slate-500'}`}>
              <span className="w-2 h-2 rounded-full bg-current" />
              <span>Step 1: Locking tokens on {fromChainObj.name}</span>
            </div>
            <div className={`flex items-center gap-2 ${bridgeStep >= 2 ? 'text-[#0ECB81]' : 'text-slate-500'}`}>
              <span className="w-2 h-2 rounded-full bg-current" />
              <span>Step 2: Relayer cryptographic validation</span>
            </div>
            <div className={`flex items-center gap-2 ${bridgeStep >= 3 ? 'text-[#0ECB81]' : 'text-slate-500'}`}>
              <span className="w-2 h-2 rounded-full bg-current" />
              <span>Step 3: Releasing on {toChainObj.name}</span>
            </div>
          </div>
        </div>
      ) : (
        /* Bridge Input Form */
        <div className="space-y-3">
          {/* Chains Selector */}
          <div className="grid grid-cols-2 gap-2">
            <div className="p-2.5 rounded-xl bg-[#12161F] border border-slate-800 space-y-1">
              <span className="text-[11px] text-slate-400">From Chain</span>
              <select
                value={fromChain}
                onChange={e => setFromChain(e.target.value)}
                className="w-full bg-transparent font-bold text-white text-xs focus:outline-none cursor-pointer"
              >
                {chains.map(c => (
                  <option key={c.id} value={c.id} className="bg-[#181A20]">
                    {c.icon} {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="p-2.5 rounded-xl bg-[#12161F] border border-slate-800 space-y-1">
              <span className="text-[11px] text-slate-400">To Chain</span>
              <select
                value={toChain}
                onChange={e => setToChain(e.target.value)}
                className="w-full bg-transparent font-bold text-white text-xs focus:outline-none cursor-pointer"
              >
                {chains.map(c => (
                  <option key={c.id} value={c.id} className="bg-[#181A20]">
                    {c.icon} {c.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Token & Amount */}
          <div className="p-3 rounded-xl bg-[#12161F] border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Bridge Amount</span>
              <span>Available: {balance.toFixed(2)} {tokenSymbol}</span>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="number"
                value={amount}
                onChange={e => setAmount(e.target.value)}
                placeholder="0.0"
                className="w-full bg-transparent text-xl font-bold font-mono text-white focus:outline-none"
              />
              <select
                value={tokenSymbol}
                onChange={e => setTokenSymbol(e.target.value)}
                className="bg-[#181A20] border border-slate-700 text-white font-bold text-xs px-2.5 py-1.5 rounded-lg focus:outline-none"
              >
                <option value="USDT">USDT</option>
                <option value="USDC">USDC</option>
                <option value="ETH">ETH</option>
                <option value="SOL">SOL</option>
              </select>
            </div>
          </div>

          {/* Details */}
          <div className="p-2.5 rounded-xl bg-[#12161F]/60 border border-slate-800 text-xs space-y-1.5 text-slate-400">
            <div className="flex justify-between">
              <span>Estimated Duration:</span>
              <span className="text-slate-300 font-medium">~30–45 seconds</span>
            </div>
            <div className="flex justify-between">
              <span>Bridge Fee:</span>
              <span className="text-slate-300 font-mono">$1.20 USDT</span>
            </div>
            <div className="flex justify-between">
              <span>Security Method:</span>
              <span className="text-[#0ECB81]">Simulated Multi-Sig Threshold</span>
            </div>
          </div>

          {error && (
            <div className="p-2.5 rounded-lg bg-red-950/40 border border-red-800 text-red-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <button
            onClick={handleStartBridge}
            className="w-full py-3 rounded-xl bg-[#F0B90B] hover:bg-[#FCD535] text-black font-bold text-xs transition-colors shadow-md"
          >
            Simulate Bridge Transfer
          </button>
        </div>
      )}
    </div>
  );
};
