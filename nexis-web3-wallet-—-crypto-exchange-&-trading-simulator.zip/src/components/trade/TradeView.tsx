import React from 'react';
import { useWallet } from '../../context/WalletContext';
import { SwapTab } from './SwapTab';
import { BridgeTab } from './BridgeTab';
import { ProTab } from './ProTab';
import { PerpsTab } from './PerpsTab';

export const TradeView: React.FC = () => {
  const { tradeModeTab, setTradeModeTab } = useWallet();

  const tabs = [
    { id: 'swap' as const, label: 'Swap' },
    { id: 'pro' as const, label: 'Spot Pro' },
    { id: 'perps' as const, label: 'Perps' },
    { id: 'bridge' as const, label: 'Bridge' }
  ];

  return (
    <div className="space-y-4 pb-20">
      {/* Trade Sub-navigation Tabs */}
      <div className="flex items-center gap-1 p-1 bg-[#181A20] rounded-xl border border-[#2B313A]">
        {tabs.map(t => {
          const isActive = tradeModeTab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setTradeModeTab(t.id)}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                isActive
                  ? 'bg-[#F0B90B] text-black shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {t.label}
            </button>
          );
        })}
      </div>

      {/* Render Active Trade Sub-Tab */}
      {tradeModeTab === 'swap' && <SwapTab />}
      {tradeModeTab === 'pro' && <ProTab />}
      {tradeModeTab === 'perps' && <PerpsTab />}
      {tradeModeTab === 'bridge' && <BridgeTab />}
    </div>
  );
};
