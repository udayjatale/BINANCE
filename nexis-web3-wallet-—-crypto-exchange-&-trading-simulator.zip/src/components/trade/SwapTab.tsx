import React, { useState, useMemo, useEffect } from 'react';
import { ArrowDownUp, Settings2, Info, ChevronDown, Check, AlertCircle } from 'lucide-react';
import { useWallet } from '../../context/WalletContext';
import { Token } from '../../types/crypto';

export const SwapTab: React.FC = () => {
  const {
    tokens,
    holdings,
    executeSwap,
    tradePresetToken,
    setTradePresetToken,
    primaryCurrency
  } = useWallet();

  const [fromSymbol, setFromSymbol] = useState<string>('USDT');
  const [toSymbol, setToSymbol] = useState<string>('BTC');
  const [fromAmount, setFromAmount] = useState<string>('100');
  const [slippage, setSlippage] = useState<number>(0.5);
  const [showSettings, setShowSettings] = useState<boolean>(false);
  const [showFromPicker, setShowFromPicker] = useState<boolean>(false);
  const [showToPicker, setShowToPicker] = useState<boolean>(false);
  const [isPreviewModalOpen, setIsPreviewModalOpen] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // If a token was preset from Market/Home detail, handle it
  useEffect(() => {
    if (tradePresetToken) {
      if (tradePresetToken.symbol === 'USDT') {
        setFromSymbol('BTC');
        setToSymbol('USDT');
      } else {
        setToSymbol(tradePresetToken.symbol);
      }
      setTradePresetToken(null);
    }
  }, [tradePresetToken, setTradePresetToken]);

  const fromToken = tokens.find(t => t.symbol === fromSymbol) || tokens[0];
  const toToken = tokens.find(t => t.symbol === toSymbol) || tokens[1];

  const fromBalance = holdings[fromSymbol] || 0;
  const toBalance = holdings[toSymbol] || 0;

  // Conversion calculations
  const parsedFromAmount = parseFloat(fromAmount) || 0;
  const fromPriceUsd = fromToken.priceUsd;
  const toPriceUsd = toToken.priceUsd;

  const totalUsdValue = parsedFromAmount * fromPriceUsd;
  const feeRate = 0.0015; // 0.15% simulated protocol fee
  const feeUsd = totalUsdValue * feeRate;
  const netUsdValue = Math.max(0, totalUsdValue - feeUsd);

  const calculatedToAmount = toPriceUsd > 0 ? netUsdValue / toPriceUsd : 0;
  const minReceived = calculatedToAmount * (1 - slippage / 100);
  const exchangeRate = toPriceUsd > 0 ? fromPriceUsd / toPriceUsd : 0;

  const handleFlipTokens = () => {
    setFromSymbol(toSymbol);
    setToSymbol(fromSymbol);
    setFromAmount(calculatedToAmount > 0 ? calculatedToAmount.toFixed(4) : '');
  };

  const setPercentAmount = (pct: number) => {
    const amt = fromBalance * (pct / 100);
    setFromAmount(amt > 0 ? (amt < 0.0001 ? amt.toFixed(6) : amt.toFixed(4)) : '0');
  };

  const handlePreviewSwap = () => {
    setErrorMessage(null);
    if (parsedFromAmount <= 0) {
      setErrorMessage('Please enter an amount greater than 0.');
      return;
    }
    if (fromBalance < parsedFromAmount) {
      setErrorMessage(`Insufficient ${fromSymbol} balance. You have ${fromBalance.toFixed(4)} ${fromSymbol}.`);
      return;
    }
    if (fromSymbol === toSymbol) {
      setErrorMessage('Please select two different tokens to swap.');
      return;
    }
    setIsPreviewModalOpen(true);
  };

  const handleConfirmSwap = () => {
    const res = executeSwap(fromSymbol, toSymbol, parsedFromAmount, calculatedToAmount, feeUsd);
    if (!res.success) {
      setErrorMessage(res.error || 'Failed to execute swap.');
      setIsPreviewModalOpen(false);
      return;
    }
    setIsPreviewModalOpen(false);
    setFromAmount('');
  };

  return (
    <div className="space-y-4">
      {/* Quick Conversion Shortcuts Bar (e.g. Convert NEX to Binance BNB) */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
        <span className="text-[11px] text-slate-400 font-semibold uppercase tracking-wider shrink-0 mr-1">
          Quick Convert:
        </span>
        <button
          onClick={() => {
            setFromSymbol('NEX');
            setToSymbol('BNB');
            const nexBal = holdings['NEX'] || 0;
            setFromAmount(nexBal > 0 ? nexBal.toString() : '50');
          }}
          className={`px-2.5 py-1 rounded-lg text-xs font-bold whitespace-nowrap transition-all border ${
            fromSymbol === 'NEX' && toSymbol === 'BNB'
              ? 'bg-[#F0B90B] text-black border-[#F0B90B]'
              : 'bg-[#181A20] text-slate-300 hover:text-white border-[#2B313A]'
          }`}
        >
          ⚡ NEX → Binance (BNB)
        </button>

        <button
          onClick={() => {
            setFromSymbol('USDT');
            setToSymbol('BNB');
            setFromAmount('100');
          }}
          className={`px-2.5 py-1 rounded-lg text-xs font-bold whitespace-nowrap transition-all border ${
            fromSymbol === 'USDT' && toSymbol === 'BNB'
              ? 'bg-[#F0B90B] text-black border-[#F0B90B]'
              : 'bg-[#181A20] text-slate-300 hover:text-white border-[#2B313A]'
          }`}
        >
          USDT → Binance (BNB)
        </button>

        <button
          onClick={() => {
            setFromSymbol('BTC');
            setToSymbol('BNB');
            setFromAmount('0.001');
          }}
          className={`px-2.5 py-1 rounded-lg text-xs font-bold whitespace-nowrap transition-all border ${
            fromSymbol === 'BTC' && toSymbol === 'BNB'
              ? 'bg-[#F0B90B] text-black border-[#F0B90B]'
              : 'bg-[#181A20] text-slate-300 hover:text-white border-[#2B313A]'
          }`}
        >
          BTC → Binance (BNB)
        </button>
      </div>

      {/* Swap Box Container */}
      <div className="bg-[#181A20] border border-[#2B313A] rounded-2xl p-4 shadow-lg space-y-3 relative">
        {/* Header with Slippage Settings Toggle */}
        <div className="flex items-center justify-between pb-1 border-b border-slate-800/80">
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-sm text-white">Binance Web3 Spot Swap</span>
            <span className="text-[10px] font-semibold text-[#0ECB81] bg-[#0ECB81]/15 px-1.5 py-0.2 rounded">
              0.15% Fee
            </span>
          </div>

          <button
            onClick={() => setShowSettings(!showSettings)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Slippage settings"
          >
            <Settings2 className="w-4 h-4" />
          </button>
        </div>

        {/* Slippage Settings Drawer */}
        {showSettings && (
          <div className="p-3 bg-[#12161F] rounded-xl border border-slate-800 space-y-2 text-xs">
            <div className="flex items-center justify-between text-slate-400">
              <span>Slippage Tolerance</span>
              <span className="font-semibold text-white">{slippage}%</span>
            </div>
            <div className="flex items-center gap-2">
              {[0.1, 0.5, 1.0].map(s => (
                <button
                  key={s}
                  onClick={() => setSlippage(s)}
                  className={`flex-1 py-1.5 rounded-lg font-semibold transition-colors ${
                    slippage === s
                      ? 'bg-[#F0B90B] text-black'
                      : 'bg-[#181A20] text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  {s}%
                </button>
              ))}
            </div>
          </div>
        )}

        {/* FROM Token Input Card */}
        <div className="bg-[#12161F] border border-slate-800 rounded-xl p-3 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>You Pay</span>
            <div className="flex items-center gap-1">
              <span>Balance:</span>
              <button
                onClick={() => setPercentAmount(100)}
                className="font-mono text-slate-200 hover:text-[#F0B90B] underline font-semibold"
              >
                {fromBalance.toFixed(4)} {fromSymbol}
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between gap-3">
            <input
              type="number"
              value={fromAmount}
              onChange={e => setFromAmount(e.target.value)}
              placeholder="0.0"
              className="w-full bg-transparent text-2xl font-bold font-mono text-white focus:outline-none placeholder:text-slate-600"
            />

            {/* Token Selector Trigger */}
            <button
              onClick={() => setShowFromPicker(true)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#181A20] hover:bg-[#202530] border border-slate-700 text-white font-bold text-xs shrink-0 transition-colors"
            >
              <div
                className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] text-white"
                style={{ backgroundColor: fromToken.iconBg }}
              >
                {fromToken.symbol.slice(0, 3)}
              </div>
              <span>{fromToken.symbol}</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
            <span className="font-mono text-[11px]">
              ≈ ${totalUsdValue.toFixed(2)} USDT
            </span>

            {/* Percentage shortcuts */}
            <div className="flex items-center gap-1">
              {[25, 50, 75, 100].map(pct => (
                <button
                  key={pct}
                  onClick={() => setPercentAmount(pct)}
                  className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300"
                >
                  {pct}%
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Flip Tokens Button */}
        <div className="flex justify-center -my-2 relative z-10">
          <button
            onClick={handleFlipTokens}
            className="w-8 h-8 rounded-full bg-[#181A20] hover:bg-[#202530] border-2 border-[#2B313A] text-slate-300 hover:text-[#F0B90B] flex items-center justify-center shadow-md transition-all active:scale-95"
            title="Invert tokens"
          >
            <ArrowDownUp className="w-4 h-4" />
          </button>
        </div>

        {/* TO Token Receive Card */}
        <div className="bg-[#12161F] border border-slate-800 rounded-xl p-3 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>You Receive (Estimated)</span>
            <div className="flex items-center gap-1">
              <span>Balance:</span>
              <span className="font-mono text-slate-300">
                {toBalance.toFixed(4)} {toSymbol}
              </span>
            </div>
          </div>

          <div className="flex items-center justify-between gap-3">
            <div className="w-full text-2xl font-bold font-mono text-[#0ECB81] select-none truncate">
              {calculatedToAmount > 0
                ? (calculatedToAmount < 0.0001
                    ? calculatedToAmount.toFixed(6)
                    : calculatedToAmount.toFixed(4))
                : '0.00'}
            </div>

            {/* Token Selector Trigger */}
            <button
              onClick={() => setShowToPicker(true)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#181A20] hover:bg-[#202530] border border-slate-700 text-white font-bold text-xs shrink-0 transition-colors"
            >
              <div
                className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] text-white"
                style={{ backgroundColor: toToken.iconBg }}
              >
                {toToken.symbol.slice(0, 3)}
              </div>
              <span>{toToken.symbol}</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
            <span className="font-mono text-[11px]">
              ≈ ${netUsdValue.toFixed(2)} USDT
            </span>
            <span className="text-[11px] text-slate-400 font-mono">
              1 {fromSymbol} = {exchangeRate < 0.001 ? exchangeRate.toFixed(6) : exchangeRate.toFixed(4)} {toSymbol}
            </span>
          </div>
        </div>

        {/* Routing & Breakdown Accordion */}
        <div className="p-2.5 rounded-xl bg-[#12161F]/60 border border-slate-800/60 text-xs space-y-1.5 text-slate-400">
          <div className="flex items-center justify-between">
            <span>Simulated Route:</span>
            <span className="text-slate-300 font-medium">Binance Web3 AMM Router (BNB Chain)</span>
          </div>
          <div className="flex items-center justify-between">
            <span>Trading Fee (0.15%):</span>
            <span className="text-slate-300 font-mono">${feeUsd.toFixed(2)}</span>
          </div>
          <div className="flex items-center justify-between">
            <span>Min. Received ({100 - slippage}%):</span>
            <span className="text-slate-300 font-mono">
              {minReceived < 0.0001 ? minReceived.toFixed(6) : minReceived.toFixed(4)} {toSymbol}
            </span>
          </div>
        </div>

        {/* Error message */}
        {errorMessage && (
          <div className="p-2.5 rounded-xl bg-red-950/40 border border-red-800 text-red-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Preview Swap CTA */}
        <button
          onClick={handlePreviewSwap}
          className="w-full py-3.5 rounded-xl bg-[#F0B90B] hover:bg-[#FCD535] text-black font-bold text-sm transition-all shadow-md shadow-[#F0B90B]/15 active:scale-[0.99]"
        >
          Preview Swap
        </button>
      </div>

      {/* From Token Picker Modal */}
      {showFromPicker && (
        <TokenPickerModal
          tokens={tokens}
          currentSymbol={fromSymbol}
          onSelect={tok => {
            setFromSymbol(tok.symbol);
            setShowFromPicker(false);
          }}
          onClose={() => setShowFromPicker(false)}
        />
      )}

      {/* To Token Picker Modal */}
      {showToPicker && (
        <TokenPickerModal
          tokens={tokens}
          currentSymbol={toSymbol}
          onSelect={tok => {
            setToSymbol(tok.symbol);
            setShowToPicker(false);
          }}
          onClose={() => setShowToPicker(false)}
        />
      )}

      {/* Preview Confirmation Modal */}
      {isPreviewModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
          <div className="bg-[#181A20] border border-[#2B313A] w-full max-w-sm rounded-t-3xl sm:rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#2B313A]">
              <h3 className="font-bold text-white text-base">Confirm Demo Swap</h3>
              <button
                onClick={() => setIsPreviewModalOpen(false)}
                className="text-slate-400 hover:text-white text-xs px-2 py-1"
              >
                ✕
              </button>
            </div>

            <div className="p-4 rounded-xl bg-[#12161F] border border-slate-800 text-center space-y-2">
              <span className="text-xs text-slate-400">You are converting</span>
              <div className="text-2xl font-black font-mono text-white">
                {parsedFromAmount} {fromSymbol}
              </div>
              <div className="text-xs text-slate-500">↓</div>
              <div className="text-2xl font-black font-mono text-[#0ECB81]">
                {calculatedToAmount < 0.0001
                  ? calculatedToAmount.toFixed(6)
                  : calculatedToAmount.toFixed(4)}{' '}
                {toSymbol}
              </div>
            </div>

            <div className="space-y-1.5 text-xs text-slate-400">
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span>Exchange Rate</span>
                <span className="font-mono text-white">
                  1 {fromSymbol} ≈ {exchangeRate < 0.001 ? exchangeRate.toFixed(6) : exchangeRate.toFixed(4)} {toSymbol}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span>Protocol Fee</span>
                <span className="font-mono text-white">${feeUsd.toFixed(2)} USDT</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span>Network Execution</span>
                <span className="text-[#0ECB81] font-semibold">Simulated Instant Block</span>
              </div>
            </div>

            <div className="p-2.5 rounded-lg bg-[#F0B90B]/10 border border-[#F0B90B]/20 text-[11px] text-[#F0B90B]">
              This is an educational simulation. No actual crypto tokens are transferred or transacted on a live blockchain.
            </div>

            <button
              onClick={handleConfirmSwap}
              className="w-full py-3 rounded-xl bg-[#F0B90B] hover:bg-[#FCD535] text-black font-bold text-sm transition-colors shadow-md"
            >
              Confirm Demo Swap
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

// Reusable Token Picker Sub-component
interface TokenPickerModalProps {
  tokens: Token[];
  currentSymbol: string;
  onSelect: (token: Token) => void;
  onClose: () => void;
}

const TokenPickerModal: React.FC<TokenPickerModalProps> = ({
  tokens,
  currentSymbol,
  onSelect,
  onClose
}) => {
  const [search, setSearch] = useState('');

  const filtered = tokens.filter(
    t =>
      t.symbol.toLowerCase().includes(search.toLowerCase()) ||
      t.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="bg-[#181A20] border border-[#2B313A] w-full max-w-sm rounded-t-3xl sm:rounded-2xl max-h-[80vh] flex flex-col p-4 shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h4 className="font-bold text-white text-sm">Select Token</h4>
          <button onClick={onClose} className="text-slate-400 hover:text-white text-xs px-2 py-1">
            ✕
          </button>
        </div>

        <div className="my-3">
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search token name or symbol..."
            className="w-full px-3 py-2 rounded-xl bg-[#12161F] border border-slate-700 text-xs text-white focus:outline-none focus:border-[#F0B90B]"
            autoFocus
          />
        </div>

        <div className="overflow-y-auto divide-y divide-slate-800 flex-1">
          {filtered.map(tok => {
            const isSelected = tok.symbol === currentSymbol;
            return (
              <div
                key={tok.symbol}
                onClick={() => onSelect(tok)}
                className={`flex items-center justify-between px-3 py-2.5 hover:bg-slate-800/60 cursor-pointer rounded-lg transition-colors ${
                  isSelected ? 'bg-slate-800/80' : ''
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white"
                    style={{ backgroundColor: tok.iconBg }}
                  >
                    {tok.symbol.slice(0, 3)}
                  </div>
                  <div>
                    <span className="font-bold text-xs text-white block">{tok.symbol}</span>
                    <span className="text-[10px] text-slate-400 block">{tok.name}</span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="font-mono text-xs text-slate-200 block">
                    ${tok.priceUsd.toFixed(tok.priceUsd < 1 ? 4 : 2)}
                  </span>
                  {isSelected && <Check className="w-3.5 h-3.5 text-[#F0B90B] ml-auto mt-0.5" />}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
