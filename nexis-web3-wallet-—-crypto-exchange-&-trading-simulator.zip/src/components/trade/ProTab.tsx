import React, { useState, useMemo } from 'react';
import { ArrowDown, ArrowUp, CheckCircle, Clock } from 'lucide-react';
import { useWallet } from '../../context/WalletContext';

export const ProTab: React.FC = () => {
  const { tokens, holdings, executeDeposit, executeWithdraw } = useWallet();

  const [selectedPair, setSelectedPair] = useState<string>('BTC/USDT');
  const [orderSide, setOrderSide] = useState<'buy' | 'sell'>('buy');
  const [orderType, setOrderType] = useState<'market' | 'limit'>('limit');
  const [limitPrice, setLimitPrice] = useState<string>('');
  const [amountTokens, setAmountTokens] = useState<string>('0.01');
  const [notification, setNotification] = useState<string | null>(null);

  const baseSymbol = selectedPair.split('/')[0];
  const quoteSymbol = selectedPair.split('/')[1];

  const currentToken = tokens.find(t => t.symbol === baseSymbol) || tokens[0];
  const currentPrice = currentToken.priceUsd;

  // Set default limit price when switching pairs or on initial load
  React.useEffect(() => {
    setLimitPrice(currentPrice.toString());
  }, [selectedPair, currentPrice]);

  const baseBalance = holdings[baseSymbol] || 0;
  const quoteBalance = holdings[quoteSymbol] || 0;

  // Order book mock data centered around current price
  const orderBook = useMemo(() => {
    const asks: { price: number; amount: number; total: number }[] = [];
    const bids: { price: number; amount: number; total: number }[] = [];

    for (let i = 4; i >= 1; i--) {
      const p = currentPrice * (1 + i * 0.0008);
      const a = Number((Math.random() * 1.5 + 0.1).toFixed(4));
      asks.push({ price: p, amount: a, total: p * a });
    }

    for (let i = 1; i <= 4; i++) {
      const p = currentPrice * (1 - i * 0.0008);
      const a = Number((Math.random() * 1.8 + 0.15).toFixed(4));
      bids.push({ price: p, amount: a, total: p * a });
    }

    return { asks, bids };
  }, [currentPrice]);

  const parsedAmount = parseFloat(amountTokens) || 0;
  const effectivePrice = orderType === 'market' ? currentPrice : (parseFloat(limitPrice) || currentPrice);
  const totalCostUsd = parsedAmount * effectivePrice;

  const handlePlaceOrder = () => {
    setNotification(null);
    if (parsedAmount <= 0) {
      setNotification('Please enter a valid order size.');
      return;
    }

    if (orderSide === 'buy') {
      if (quoteBalance < totalCostUsd) {
        setNotification(`Insufficient ${quoteSymbol}. Available: $${quoteBalance.toFixed(2)}`);
        return;
      }
      // Deduct quote, add base
      executeWithdraw(quoteSymbol, totalCostUsd, 'Spot Order Book', 'Internal Spot Engine');
      executeDeposit(baseSymbol, parsedAmount, `Spot Buy ${selectedPair} @ $${effectivePrice.toFixed(2)}`);
      setNotification(`Demo ${orderSide.toUpperCase()} Order executed! Bought ${parsedAmount} ${baseSymbol}.`);
    } else {
      if (baseBalance < parsedAmount) {
        setNotification(`Insufficient ${baseSymbol}. Available: ${baseBalance.toFixed(4)}`);
        return;
      }
      // Deduct base, add quote
      executeWithdraw(baseSymbol, parsedAmount, 'Spot Order Book', 'Internal Spot Engine');
      executeDeposit(quoteSymbol, totalCostUsd, `Spot Sell ${selectedPair} @ $${effectivePrice.toFixed(2)}`);
      setNotification(`Demo ${orderSide.toUpperCase()} Order executed! Sold ${parsedAmount} ${baseSymbol} for $${totalCostUsd.toFixed(2)}.`);
    }

    setTimeout(() => setNotification(null), 3500);
  };

  return (
    <div className="space-y-4">
      {/* Pair Header & 24h ticker info */}
      <div className="bg-[#181A20] border border-[#2B313A] rounded-2xl p-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <select
            value={selectedPair}
            onChange={e => setSelectedPair(e.target.value)}
            className="bg-[#12161F] text-white font-bold text-sm px-2.5 py-1 rounded-lg border border-slate-700 focus:outline-none cursor-pointer"
          >
            <option value="BTC/USDT">BTC/USDT</option>
            <option value="BNB/USDT">BNB/USDT</option>
            <option value="ETH/USDT">ETH/USDT</option>
            <option value="SOL/USDT">SOL/USDT</option>
          </select>
          <div className="text-sm font-bold font-mono text-white">
            ${currentPrice.toFixed(currentPrice < 1 ? 4 : 2)}
          </div>
        </div>

        <div className={`text-xs font-bold font-mono px-2 py-0.5 rounded ${
          currentToken.change24h >= 0 ? 'bg-[#0ECB81]/15 text-[#0ECB81]' : 'bg-[#F6465D]/15 text-[#F6465D]'
        }`}>
          {currentToken.change24h >= 0 ? '+' : ''}{currentToken.change24h}%
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Order Book Column */}
        <div className="bg-[#181A20] border border-[#2B313A] rounded-2xl p-3 space-y-2">
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-semibold uppercase tracking-wider pb-1 border-b border-slate-800">
            <span>Price (USDT)</span>
            <span>Size ({baseSymbol})</span>
            <span>Total</span>
          </div>

          {/* Asks (Sell Orders - Red) */}
          <div className="space-y-1 text-xs font-mono">
            {orderBook.asks.map((ask, i) => (
              <div key={i} className="flex items-center justify-between text-slate-300 relative py-0.5">
                <div
                  className="absolute right-0 top-0 bottom-0 bg-[#F6465D]/10 rounded"
                  style={{ width: `${Math.min(100, (ask.amount / 2) * 100)}%` }}
                />
                <span className="text-[#F6465D] relative z-10 font-medium">
                  {ask.price.toFixed(ask.price < 1 ? 4 : 2)}
                </span>
                <span className="relative z-10">{ask.amount.toFixed(4)}</span>
                <span className="text-slate-400 text-[11px] relative z-10">${ask.total.toFixed(1)}</span>
              </div>
            ))}
          </div>

          {/* Center Spread Price */}
          <div className="py-1.5 px-2 bg-[#12161F] rounded-lg text-center font-bold font-mono text-base text-white border border-slate-800">
            ${currentPrice.toFixed(currentPrice < 1 ? 4 : 2)}
            <span className="text-xs text-slate-400 font-normal ml-2">Market Price</span>
          </div>

          {/* Bids (Buy Orders - Green) */}
          <div className="space-y-1 text-xs font-mono">
            {orderBook.bids.map((bid, i) => (
              <div key={i} className="flex items-center justify-between text-slate-300 relative py-0.5">
                <div
                  className="absolute right-0 top-0 bottom-0 bg-[#0ECB81]/10 rounded"
                  style={{ width: `${Math.min(100, (bid.amount / 2) * 100)}%` }}
                />
                <span className="text-[#0ECB81] relative z-10 font-medium">
                  {bid.price.toFixed(bid.price < 1 ? 4 : 2)}
                </span>
                <span className="relative z-10">{bid.amount.toFixed(4)}</span>
                <span className="text-slate-400 text-[11px] relative z-10">${bid.total.toFixed(1)}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Order Entry Column */}
        <div className="bg-[#181A20] border border-[#2B313A] rounded-2xl p-4 space-y-3">
          {/* Buy / Sell Tabs */}
          <div className="grid grid-cols-2 gap-1.5 bg-[#12161F] p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => setOrderSide('buy')}
              className={`py-2 rounded-lg font-bold text-xs transition-colors ${
                orderSide === 'buy' ? 'bg-[#0ECB81] text-black shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Buy {baseSymbol}
            </button>
            <button
              onClick={() => setOrderSide('sell')}
              className={`py-2 rounded-lg font-bold text-xs transition-colors ${
                orderSide === 'sell' ? 'bg-[#F6465D] text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Sell {baseSymbol}
            </button>
          </div>

          {/* Order Type: Market vs Limit */}
          <div className="flex items-center gap-2 text-xs">
            <button
              onClick={() => setOrderType('limit')}
              className={`px-3 py-1 rounded-lg font-semibold ${
                orderType === 'limit' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Limit
            </button>
            <button
              onClick={() => setOrderType('market')}
              className={`px-3 py-1 rounded-lg font-semibold ${
                orderType === 'market' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Market
            </button>
          </div>

          {/* Inputs */}
          {orderType === 'limit' && (
            <div className="space-y-1">
              <span className="text-[11px] text-slate-400">Order Price (USDT)</span>
              <input
                type="number"
                value={limitPrice}
                onChange={e => setLimitPrice(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#12161F] border border-slate-800 text-white font-mono text-sm focus:outline-none focus:border-[#F0B90B]"
              />
            </div>
          )}

          <div className="space-y-1">
            <div className="flex justify-between text-[11px] text-slate-400">
              <span>Amount ({baseSymbol})</span>
              <span>
                Avail: {orderSide === 'buy' ? `$${quoteBalance.toFixed(2)} USDT` : `${baseBalance.toFixed(4)} ${baseSymbol}`}
              </span>
            </div>
            <input
              type="number"
              value={amountTokens}
              onChange={e => setAmountTokens(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-[#12161F] border border-slate-800 text-white font-mono text-sm focus:outline-none focus:border-[#F0B90B]"
            />
          </div>

          {/* Order Value summary */}
          <div className="p-2.5 rounded-xl bg-[#12161F] border border-slate-800 text-xs text-slate-400 space-y-1">
            <div className="flex justify-between">
              <span>Order Value:</span>
              <span className="font-mono text-white font-semibold">${totalCostUsd.toFixed(2)} USDT</span>
            </div>
            <div className="flex justify-between">
              <span>Maker / Taker Fee:</span>
              <span className="text-slate-300">0.02% (Simulated)</span>
            </div>
          </div>

          {notification && (
            <div className="p-2.5 rounded-lg bg-slate-800 text-xs text-[#F0B90B] border border-slate-700">
              {notification}
            </div>
          )}

          <button
            onClick={handlePlaceOrder}
            className={`w-full py-3 rounded-xl font-bold text-xs transition-colors shadow-md ${
              orderSide === 'buy'
                ? 'bg-[#0ECB81] hover:bg-[#02C076] text-black'
                : 'bg-[#F6465D] hover:bg-[#E03149] text-white'
            }`}
          >
            Place {orderSide.toUpperCase()} Demo Order
          </button>
        </div>
      </div>
    </div>
  );
};
