import React from 'react';
import { Star, X, ArrowUpRight, TrendingUp, DollarSign, Layers } from 'lucide-react';
import { Token } from '../../types/crypto';
import { useWallet } from '../../context/WalletContext';
import { InteractiveChart } from '../common/InteractiveChart';
import { USD_TO_INR_RATE } from '../../data/mockTokens';

interface TokenDetailModalProps {
  token: Token;
  onClose: () => void;
}

export const TokenDetailModal: React.FC<TokenDetailModalProps> = ({ token, onClose }) => {
  const {
    isFavorite,
    toggleFavorite,
    primaryCurrency,
    setActiveTab,
    setTradePresetToken,
    setTradeModeTab
  } = useWallet();

  const isFav = isFavorite(token.symbol);
  const isPositive = token.change24h >= 0;

  const currencySymbol = primaryCurrency === 'INR' ? '₹' : '$';
  const currencyRate = primaryCurrency === 'INR' ? USD_TO_INR_RATE : 1;

  const handleOpenTrade = () => {
    setTradePresetToken(token);
    setTradeModeTab('swap');
    setActiveTab('trade');
    onClose();
  };

  const handleOpenPerps = () => {
    setTradePresetToken(token);
    setTradeModeTab('perps');
    setActiveTab('trade');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-[#12161F] border border-[#2B313A] w-full max-w-lg rounded-t-3xl sm:rounded-2xl max-h-[92vh] flex flex-col overflow-hidden shadow-2xl">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-[#1E2329] bg-[#181A20]/80">
          <div className="flex items-center gap-3">
            <div
              className="w-9 h-9 rounded-full flex items-center justify-center font-bold text-white text-sm shadow-sm"
              style={{ backgroundColor: token.iconBg }}
            >
              {token.symbol.slice(0, 3)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-white text-base">{token.name}</h3>
                <span className="text-xs font-semibold px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                  {token.symbol}
                </span>
                {token.isFictional && (
                  <span className="text-[10px] font-medium px-1.5 py-0.2 rounded bg-[#F0B90B]/15 text-[#F0B90B]">
                    Demo Asset
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400 capitalize">{token.category} · {token.network || 'Mainnet'}</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => toggleFavorite(token.symbol)}
              className="w-9 h-9 rounded-lg flex items-center justify-center bg-[#181A20] hover:bg-[#2B313A] transition-colors"
              title="Add to Favorites"
            >
              <Star
                className={`w-4 h-4 ${
                  isFav ? 'text-[#F0B90B] fill-[#F0B90B]' : 'text-slate-400'
                }`}
              />
            </button>
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-lg flex items-center justify-center bg-[#181A20] hover:bg-[#2B313A] text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Body */}
        <div className="p-5 overflow-y-auto space-y-5">
          {/* Main Price & 24h change */}
          <div className="flex items-baseline justify-between">
            <div>
              <div className="text-3xl font-extrabold font-mono text-white tracking-tight">
                {currencySymbol}
                {(token.priceUsd * currencyRate).toLocaleString(undefined, {
                  minimumFractionDigits: token.priceUsd < 1 ? 4 : 2,
                  maximumFractionDigits: token.priceUsd < 1 ? 6 : 2
                })}
              </div>
              <div className="text-xs text-slate-400 font-mono mt-0.5">
                ≈ {primaryCurrency === 'INR' ? `$${token.priceUsd.toFixed(2)}` : `₹${Math.round(token.priceInr).toLocaleString()}`}
              </div>
            </div>

            <div
              className={`px-3 py-1.5 rounded-lg text-sm font-bold font-mono flex items-center gap-1 ${
                isPositive
                  ? 'bg-[#0ECB81]/15 text-[#0ECB81]'
                  : 'bg-[#F6465D]/15 text-[#F6465D]'
              }`}
            >
              {isPositive ? '+' : ''}
              {token.change24h}%
            </div>
          </div>

          {/* Interactive Chart */}
          <InteractiveChart
            basePrice={token.priceUsd}
            symbol={token.symbol}
            isPositive={isPositive}
            currencySymbol={currencySymbol}
            currencyRate={currencyRate}
          />

          {/* Key Metrics Grid */}
          <div className="space-y-2">
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Market Statistics (Simulated)
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-[#181A20] border border-slate-800">
                <span className="text-slate-400 block text-[11px]">24h High</span>
                <span className="font-semibold font-mono text-white mt-0.5 block">
                  {currencySymbol}{(token.high24h * currencyRate).toFixed(token.high24h < 1 ? 4 : 2)}
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-[#181A20] border border-slate-800">
                <span className="text-slate-400 block text-[11px]">24h Low</span>
                <span className="font-semibold font-mono text-white mt-0.5 block">
                  {currencySymbol}{(token.low24h * currencyRate).toFixed(token.low24h < 1 ? 4 : 2)}
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-[#181A20] border border-slate-800">
                <span className="text-slate-400 block text-[11px]">24h Volume</span>
                <span className="font-semibold font-mono text-white mt-0.5 block">
                  ${(token.volume24hUsd / 1e6).toFixed(1)}M
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-[#181A20] border border-slate-800">
                <span className="text-slate-400 block text-[11px]">Market Cap</span>
                <span className="font-semibold font-mono text-white mt-0.5 block">
                  ${(token.marketCapUsd / 1e9).toFixed(2)}B
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-[#181A20] border border-slate-800">
                <span className="text-slate-400 block text-[11px]">Circulating Supply</span>
                <span className="font-semibold font-mono text-white mt-0.5 block">
                  {token.circulatingSupply}
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-[#181A20] border border-slate-800">
                <span className="text-slate-400 block text-[11px]">All-Time High</span>
                <span className="font-semibold font-mono text-white mt-0.5 block">
                  ${token.allTimeHighUsd.toFixed(2)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons Footer */}
        <div className="p-4 border-t border-[#1E2329] bg-[#181A20]/95 flex items-center gap-3">
          <button
            onClick={handleOpenPerps}
            className="flex-1 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs transition-colors flex items-center justify-center gap-1.5"
          >
            <TrendingUp className="w-4 h-4 text-[#F0B90B]" />
            <span>Perp Futures</span>
          </button>

          <button
            onClick={handleOpenTrade}
            className="flex-1 py-3 rounded-xl bg-[#F0B90B] hover:bg-[#FCD535] text-black font-bold text-xs transition-colors flex items-center justify-center gap-1.5 shadow-md shadow-[#F0B90B]/15"
          >
            <ArrowUpRight className="w-4 h-4" />
            <span>Trade / Swap {token.symbol}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
