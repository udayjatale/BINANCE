import React, { useState, useMemo } from 'react';
import { Search, Star, ArrowUpDown, Filter, ChevronDown } from 'lucide-react';
import { useWallet } from '../../context/WalletContext';
import { Sparkline } from '../common/Sparkline';
import { Token } from '../../types/crypto';

export const MarketsView: React.FC = () => {
  const {
    tokens,
    favorites,
    isFavorite,
    toggleFavorite,
    setSelectedToken,
    primaryCurrency
  } = useWallet();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'volume' | 'price_desc' | 'price_asc' | 'change_desc' | 'change_asc' | 'name'>('volume');

  const categories = [
    { id: 'all', label: 'All' },
    { id: 'favorites', label: '★ Favorites' },
    { id: 'layer1', label: 'Layer 1' },
    { id: 'defi', label: 'DeFi' },
    { id: 'meme', label: 'Meme' },
    { id: 'ai', label: 'AI' }
  ];

  const filteredTokens = useMemo(() => {
    let result = [...tokens];

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(
        t => t.symbol.toLowerCase().includes(q) || t.name.toLowerCase().includes(q)
      );
    }

    // Category filter
    if (selectedCategory === 'favorites') {
      result = result.filter(t => favorites.includes(t.symbol));
    } else if (selectedCategory !== 'all') {
      result = result.filter(t => t.category === selectedCategory);
    }

    // Sorting
    switch (sortBy) {
      case 'price_desc':
        result.sort((a, b) => b.priceUsd - a.priceUsd);
        break;
      case 'price_asc':
        result.sort((a, b) => a.priceUsd - b.priceUsd);
        break;
      case 'change_desc':
        result.sort((a, b) => b.change24h - a.change24h);
        break;
      case 'change_asc':
        result.sort((a, b) => a.change24h - b.change24h);
        break;
      case 'name':
        result.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'volume':
      default:
        result.sort((a, b) => b.volume24hUsd - a.volume24hUsd);
        break;
    }

    return result;
  }, [tokens, searchQuery, selectedCategory, sortBy, favorites]);

  const currencySymbol = primaryCurrency === 'INR' ? '₹' : '$';

  return (
    <div className="space-y-4 pb-20">
      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          placeholder="Search by token name or symbol (e.g. BTC, ETH, NEX)..."
          className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#181A20] border border-[#2B313A] text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-[#F0B90B] transition-colors"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs px-1"
          >
            ✕
          </button>
        )}
      </div>

      {/* Category Horizontal Filter Bar */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
        {categories.map(cat => {
          const isActive = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-[#F0B90B] text-black shadow-sm'
                  : 'bg-[#181A20] text-slate-400 hover:text-white border border-[#2B313A]'
              }`}
            >
              {cat.label}
            </button>
          );
        })}
      </div>

      {/* Sort Bar */}
      <div className="flex items-center justify-between text-xs text-slate-400 px-2 pt-1 border-b border-slate-800 pb-2">
        <span className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">
          Market / Volume
        </span>

        <div className="flex items-center gap-2">
          <span className="text-[11px] text-slate-500">Sort by:</span>
          <select
            value={sortBy}
            onChange={e => setSortBy(e.target.value as any)}
            className="bg-[#181A20] border border-slate-800 rounded-md px-2 py-1 text-xs text-slate-300 focus:outline-none focus:border-[#F0B90B]"
          >
            <option value="volume">24h Volume</option>
            <option value="change_desc">Top Gainers (%)</option>
            <option value="change_asc">Top Losers (%)</option>
            <option value="price_desc">Price (High to Low)</option>
            <option value="price_asc">Price (Low to High)</option>
            <option value="name">Name (A-Z)</option>
          </select>
        </div>
      </div>

      {/* Tokens List */}
      <div className="bg-[#181A20] border border-[#2B313A] rounded-2xl overflow-hidden divide-y divide-slate-800/80">
        {filteredTokens.length === 0 ? (
          <div className="py-16 text-center text-slate-400 text-xs">
            <Filter className="w-8 h-8 text-slate-600 mx-auto mb-2" />
            <p>No tokens match your search or filter.</p>
          </div>
        ) : (
          filteredTokens.map(tok => {
            const isPos = tok.change24h >= 0;
            const price = primaryCurrency === 'INR' ? tok.priceInr : tok.priceUsd;
            const isFav = isFavorite(tok.symbol);

            return (
              <div
                key={tok.symbol}
                onClick={() => setSelectedToken(tok)}
                className="px-4 py-3.5 hover:bg-[#1E2329] cursor-pointer flex items-center justify-between transition-colors"
              >
                {/* Left: Star + Icon + Name */}
                <div className="flex items-center gap-2.5">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(tok.symbol);
                    }}
                    className="p-1 text-slate-500 hover:text-[#F0B90B] transition-colors"
                  >
                    <Star
                      className={`w-3.5 h-3.5 ${
                        isFav ? 'text-[#F0B90B] fill-[#F0B90B]' : ''
                      }`}
                    />
                  </button>

                  <div
                    className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold text-white shrink-0"
                    style={{ backgroundColor: tok.iconBg }}
                  >
                    {tok.symbol.slice(0, 3)}
                  </div>

                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-sm text-white">{tok.symbol}</span>
                      <span className="text-[10px] text-slate-400 uppercase">/USDT</span>
                      {tok.isFictional && (
                        <span className="text-[9px] px-1 py-0.1 rounded bg-[#F0B90B]/15 text-[#F0B90B] font-semibold">
                          Demo
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-1 text-[11px] text-slate-400">
                      <span>Vol ${(tok.volume24hUsd / 1e6).toFixed(1)}M</span>
                    </div>
                  </div>
                </div>

                {/* Center: Sparkline */}
                <div className="hidden xs:block">
                  <Sparkline data={tok.sparkline} isPositive={isPos} width={76} height={26} />
                </div>

                {/* Right: Price & 24h Change */}
                <div className="text-right">
                  <div className="font-bold text-sm font-mono text-white">
                    {currencySymbol}{price.toFixed(price < 1 ? 4 : 2)}
                  </div>
                  <div
                    className={`text-[11px] font-semibold font-mono inline-block px-1.5 py-0.2 rounded mt-0.5 ${
                      isPos
                        ? 'bg-[#0ECB81]/15 text-[#0ECB81]'
                        : 'bg-[#F6465D]/15 text-[#F6465D]'
                    }`}
                  >
                    {isPos ? '+' : ''}{tok.change24h}%
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
