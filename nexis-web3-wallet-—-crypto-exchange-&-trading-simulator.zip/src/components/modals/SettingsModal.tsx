import React from 'react';
import { X, Moon, Sun, Laptop, Check, RotateCcw, Activity, ShieldCheck, DollarSign } from 'lucide-react';
import { useWallet, ThemeMode } from '../../context/WalletContext';

interface SettingsModalProps {
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ onClose }) => {
  const {
    theme,
    setTheme,
    primaryCurrency,
    setPrimaryCurrency,
    isPriceTicking,
    togglePriceTicking,
    resetDemoWallet
  } = useWallet();

  const themeOptions: { id: ThemeMode; label: string; desc: string; icon: React.FC<{ className?: string }> }[] = [
    {
      id: 'dark',
      label: 'Dark',
      desc: 'Deep dark crypto trading theme',
      icon: Moon
    },
    {
      id: 'light',
      label: 'Light',
      desc: 'Clean white theme with subtle borders',
      icon: Sun
    },
    {
      id: 'system',
      label: 'System',
      desc: 'Syncs with your device appearance',
      icon: Laptop
    }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="bg-[#181A20] border border-[#2B313A] w-full max-w-md rounded-t-3xl sm:rounded-2xl p-5 space-y-5 shadow-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h3 className="font-bold text-white text-base">Settings & Preferences</h3>
            <p className="text-xs text-slate-400">Customize appearance, currency, and wallet preferences</p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 1. Theme / Appearance Section */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Appearance & Theme
            </span>
            <span className="text-[11px] font-semibold text-[#F0B90B] capitalize">
              {theme} active
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {themeOptions.map(opt => {
              const Icon = opt.icon;
              const isSelected = theme === opt.id;

              return (
                <button
                  key={opt.id}
                  onClick={() => setTheme(opt.id)}
                  className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-all relative ${
                    isSelected
                      ? 'bg-[#F0B90B]/10 border-[#F0B90B] shadow-sm ring-1 ring-[#F0B90B]/30'
                      : 'bg-[#12161F] border-slate-800 hover:border-slate-700 text-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between w-full mb-2">
                    <div
                      className={`w-7 h-7 rounded-lg flex items-center justify-center ${
                        isSelected ? 'bg-[#F0B90B] text-black font-bold' : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    {isSelected && (
                      <span className="w-4 h-4 rounded-full bg-[#F0B90B] text-black flex items-center justify-center">
                        <Check className="w-3 h-3 stroke-[3]" />
                      </span>
                    )}
                  </div>

                  <div>
                    <span
                      className={`text-xs font-bold block ${
                        isSelected ? 'text-white' : 'text-slate-300'
                      }`}
                    >
                      {opt.label}
                    </span>
                    <span className="text-[10px] text-slate-400 leading-tight block mt-0.5">
                      {opt.desc}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* 2. Primary Currency */}
        <div className="space-y-2 pt-2 border-t border-slate-800">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-white block">Display Currency</span>
              <span className="text-[11px] text-slate-400">Switch between INR (₹) and USDT ($)</span>
            </div>

            <div className="flex items-center bg-[#12161F] p-0.5 rounded-lg border border-slate-800 text-xs">
              <button
                onClick={() => setPrimaryCurrency('INR')}
                className={`px-3 py-1.5 rounded-md font-bold text-xs transition-colors ${
                  primaryCurrency === 'INR'
                    ? 'bg-[#F0B90B] text-black shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                ₹ INR
              </button>
              <button
                onClick={() => setPrimaryCurrency('USDT')}
                className={`px-3 py-1.5 rounded-md font-bold text-xs transition-colors ${
                  primaryCurrency === 'USDT'
                    ? 'bg-[#F0B90B] text-black shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                $ USDT
              </button>
            </div>
          </div>
        </div>

        {/* 3. Live Price Updates */}
        <div className="space-y-2 pt-2 border-t border-slate-800">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-white block">Real-Time Simulation</span>
              <span className="text-[11px] text-slate-400">Simulate continuous crypto market movements</span>
            </div>

            <button
              onClick={togglePriceTicking}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors ${
                isPriceTicking
                  ? 'bg-[#0ECB81]/15 text-[#0ECB81] border border-[#0ECB81]/30'
                  : 'bg-slate-800 text-slate-400'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>{isPriceTicking ? 'Live Active' : 'Paused'}</span>
            </button>
          </div>
        </div>

        {/* 4. Reset Demo Wallet */}
        <div className="space-y-2 pt-2 border-t border-slate-800">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-white block">Reset Virtual Portfolio</span>
              <span className="text-[11px] text-slate-400">Restore default ₹100,000 starting assets</span>
            </div>

            <button
              onClick={() => {
                if (window.confirm('Reset demo portfolio back to the initial ₹100,000 balance?')) {
                  resetDemoWallet();
                  onClose();
                }
              }}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-red-950/60 hover:text-red-300 text-slate-300 border border-slate-700 font-semibold text-xs transition-colors flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          </div>
        </div>

        {/* 5. Educational Simulator Disclaimer */}
        <div className="p-3 rounded-xl bg-[#12161F] border border-slate-800 text-xs text-slate-400 space-y-1">
          <div className="flex items-center gap-1.5 text-[#F0B90B] font-bold text-[11px]">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Educational Trading Demo</span>
          </div>
          <p className="text-[11px] leading-relaxed">
            All prices, charts, staking returns, orders, and balances are purely simulated sandbox records.
          </p>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 rounded-xl bg-[#F0B90B] hover:bg-[#FCD535] text-black font-bold text-xs transition-colors shadow-md"
        >
          Save & Done
        </button>
      </div>
    </div>
  );
};
