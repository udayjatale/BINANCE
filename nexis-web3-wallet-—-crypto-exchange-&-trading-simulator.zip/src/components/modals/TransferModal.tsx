import React, { useState } from 'react';
import { ArrowLeftRight, CheckCircle } from 'lucide-react';
import { useWallet } from '../../context/WalletContext';

interface TransferModalProps {
  onClose: () => void;
}

export const TransferModal: React.FC<TransferModalProps> = ({ onClose }) => {
  const { holdings } = useWallet();
  const [fromAccount, setFromAccount] = useState('Spot Wallet');
  const [toAccount, setToAccount] = useState('Futures Account');
  const [symbol, setSymbol] = useState('USDT');
  const [amount, setAmount] = useState('100');
  const [success, setSuccess] = useState(false);

  const balance = holdings[symbol] || 0;

  const handleTransfer = () => {
    setSuccess(true);
    setTimeout(() => {
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="bg-[#181A20] border border-[#2B313A] w-full max-w-sm rounded-t-3xl sm:rounded-2xl p-5 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h3 className="font-bold text-white text-base">Internal Demo Transfer</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white text-xs px-2 py-1">
            ✕
          </button>
        </div>

        {success ? (
          <div className="py-6 text-center space-y-2">
            <CheckCircle className="w-12 h-12 text-[#0ECB81] mx-auto" />
            <h4 className="font-bold text-white text-sm">Transfer Successful!</h4>
            <p className="text-xs text-slate-400">
              Transferred {amount} {symbol} from {fromAccount} to {toAccount}.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="p-3 rounded-xl bg-[#12161F] border border-slate-800 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">From</span>
                <span className="font-bold text-white">{fromAccount}</span>
              </div>
              <div className="border-t border-slate-800 my-1" />
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">To</span>
                <span className="font-bold text-[#F0B90B]">{toAccount}</span>
              </div>
            </div>

            <div className="space-y-1">
              <span className="text-xs text-slate-400">Asset</span>
              <select
                value={symbol}
                onChange={e => setSymbol(e.target.value)}
                className="w-full p-2.5 rounded-xl bg-[#12161F] border border-slate-700 text-white font-bold text-xs"
              >
                <option value="USDT">USDT — Avail: ${(holdings['USDT'] || 0).toFixed(2)}</option>
                <option value="BTC">BTC — Avail: {(holdings['BTC'] || 0).toFixed(4)}</option>
                <option value="ETH">ETH — Avail: {(holdings['ETH'] || 0).toFixed(4)}</option>
              </select>
            </div>

            <div className="space-y-1">
              <span className="text-xs text-slate-400">Amount</span>
              <input
                type="number"
                value={amount}
                onChange={e => setAmount(e.target.value)}
                className="w-full p-2.5 rounded-xl bg-[#12161F] border border-slate-700 text-white font-mono text-sm focus:outline-none"
              />
            </div>

            <button
              onClick={handleTransfer}
              className="w-full py-3 rounded-xl bg-[#F0B90B] hover:bg-[#FCD535] text-black font-bold text-xs transition-colors shadow-md"
            >
              Confirm Transfer (Instant & Zero Fee)
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
