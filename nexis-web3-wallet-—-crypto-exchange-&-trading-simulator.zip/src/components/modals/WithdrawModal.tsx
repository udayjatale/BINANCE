import React, { useState } from 'react';
import { ArrowUpRight, AlertCircle, ShieldAlert } from 'lucide-react';
import { useWallet } from '../../context/WalletContext';

interface WithdrawModalProps {
  onClose: () => void;
}

export const WithdrawModal: React.FC<WithdrawModalProps> = ({ onClose }) => {
  const { tokens, holdings, executeWithdraw } = useWallet();

  const [selectedSymbol, setSelectedSymbol] = useState<string>('USDT');
  const [address, setAddress] = useState<string>('0x71C...48B9');
  const [amount, setAmount] = useState<string>('50');
  const [network, setNetwork] = useState<string>('Ethereum ERC-20');
  const [error, setError] = useState<string | null>(null);

  const balance = holdings[selectedSymbol] || 0;
  const parsedAmount = parseFloat(amount) || 0;

  const handleWithdraw = () => {
    setError(null);
    const res = executeWithdraw(selectedSymbol, parsedAmount, address, network);
    if (!res.success) {
      setError(res.error || 'Withdrawal failed.');
      return;
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="bg-[#181A20] border border-[#2B313A] w-full max-w-sm rounded-t-3xl sm:rounded-2xl p-5 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-white text-base">Withdraw Crypto</h3>
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-800 text-slate-300">
              BNB Chain
            </span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white text-xs px-2 py-1">
            ✕
          </button>
        </div>

        {/* Token selection */}
        <div className="space-y-1">
          <span className="text-xs text-slate-400">Select Asset</span>
          <select
            value={selectedSymbol}
            onChange={e => setSelectedSymbol(e.target.value)}
            className="w-full p-2.5 rounded-xl bg-[#12161F] border border-slate-700 text-white font-bold text-xs focus:outline-none"
          >
            {tokens.map(t => (
              <option key={t.symbol} value={t.symbol} className="bg-[#181A20]">
                {t.name} ({t.symbol}) — Bal: {(holdings[t.symbol] || 0).toFixed(4)}
              </option>
            ))}
          </select>
        </div>

        {/* Destination Address */}
        <div className="space-y-1">
          <span className="text-xs text-slate-400">Recipient Address (Simulated)</span>
          <input
            type="text"
            value={address}
            onChange={e => setAddress(e.target.value)}
            placeholder="0x..."
            className="w-full px-3 py-2 rounded-xl bg-[#12161F] border border-slate-700 text-white font-mono text-xs focus:outline-none"
          />
        </div>

        {/* Network */}
        <div className="space-y-1">
          <span className="text-xs text-slate-400">Transfer Network</span>
          <select
            value={network}
            onChange={e => setNetwork(e.target.value)}
            className="w-full p-2.5 rounded-xl bg-[#12161F] border border-slate-700 text-white text-xs focus:outline-none"
          >
            <option value="Ethereum (ERC20)">Ethereum (ERC-20)</option>
            <option value="BNB Smart Chain (BEP20)">BNB Smart Chain (BEP20)</option>
            <option value="Solana Network">Solana Network</option>
            <option value="Tron (TRC20)">Tron (TRC20)</option>
          </select>
        </div>

        {/* Amount */}
        <div className="space-y-1">
          <div className="flex justify-between text-xs text-slate-400">
            <span>Withdraw Amount</span>
            <span>Available: {balance.toFixed(4)} {selectedSymbol}</span>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="number"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              placeholder="0.0"
              className="w-full px-3 py-2 rounded-xl bg-[#12161F] border border-slate-700 text-white font-mono text-sm focus:outline-none"
            />
            <button
              onClick={() => setAmount(balance.toString())}
              className="px-3 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs"
            >
              MAX
            </button>
          </div>
        </div>

        {/* Network Fee */}
        <div className="p-2.5 rounded-xl bg-[#12161F] border border-slate-800 text-xs text-slate-400 flex justify-between">
          <span>Estimated Network Gas:</span>
          <span className="font-mono text-slate-200">$1.50 USDT (Simulated)</span>
        </div>

        {error && (
          <div className="p-2.5 rounded-lg bg-red-950/40 border border-red-800 text-red-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <button
          onClick={handleWithdraw}
          className="w-full py-3 rounded-xl bg-[#F0B90B] hover:bg-[#FCD535] text-black font-bold text-xs transition-colors shadow-md"
        >
          Confirm Demo Withdrawal
        </button>
      </div>
    </div>
  );
};
