import React, { useState } from 'react';
import { CheckCircle2, Copy, Check, ExternalLink, ShieldAlert } from 'lucide-react';
import { Transaction } from '../../types/crypto';

interface ReceiptModalProps {
  transaction: Transaction;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({ transaction, onClose }) => {
  const [copied, setCopied] = useState(false);

  const copyHash = () => {
    navigator.clipboard?.writeText(transaction.txHash);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="bg-[#181A20] border border-[#2B313A] w-full max-w-sm rounded-t-3xl sm:rounded-2xl p-5 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between pb-2 border-b border-slate-800">
          <h3 className="font-bold text-white text-base">Transaction Receipt</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-white text-xs px-2 py-1">
            ✕
          </button>
        </div>

        {/* Center Success Header */}
        <div className="text-center py-2 space-y-1">
          <div className="w-12 h-12 rounded-full bg-[#0ECB81]/15 text-[#0ECB81] flex items-center justify-center mx-auto mb-2">
            <CheckCircle2 className="w-7 h-7" />
          </div>
          <span className="text-[11px] font-bold text-[#0ECB81] uppercase tracking-wider bg-[#0ECB81]/10 px-2 py-0.5 rounded-full inline-block">
            Completed (Simulated)
          </span>
          <h4 className="font-extrabold text-white text-lg mt-1">{transaction.title}</h4>
          <p className="text-xs text-slate-400">
            {new Date(transaction.timestamp).toLocaleString()}
          </p>
        </div>

        {/* Breakdown details */}
        <div className="p-3 rounded-xl bg-[#12161F] border border-slate-800 space-y-2 text-xs text-slate-400 font-mono">
          <div className="flex justify-between">
            <span className="text-slate-400">USD Value:</span>
            <span className="text-white font-semibold">${transaction.amountUsd.toFixed(2)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">INR Equivalent:</span>
            <span className="text-white font-semibold">₹{Math.round(transaction.amountInr).toLocaleString('en-IN')}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Network Fee:</span>
            <span className="text-slate-300">${transaction.feeUsd.toFixed(2)} USDT</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Execution Network:</span>
            <span className="text-[#F0B90B] font-sans">{transaction.network}</span>
          </div>
        </div>

        {/* Simulated Tx Hash */}
        <div className="space-y-1">
          <span className="text-[11px] text-slate-400 block">Simulated Transaction Hash</span>
          <div className="flex items-center justify-between p-2 rounded-lg bg-[#12161F] border border-slate-700 text-[11px] font-mono text-slate-300">
            <span className="truncate max-w-[210px]">{transaction.txHash}</span>
            <button
              onClick={copyHash}
              className="text-slate-400 hover:text-[#F0B90B] p-1 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-[#0ECB81]" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Simulation Watermark */}
        <div className="p-2.5 rounded-xl bg-[#F0B90B]/10 border border-[#F0B90B]/20 text-[11px] text-[#F0B90B]">
          This record was generated in sandbox demo mode. No actual cryptocurrency tokens were transferred.
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition-colors"
        >
          Close Receipt
        </button>
      </div>
    </div>
  );
};
