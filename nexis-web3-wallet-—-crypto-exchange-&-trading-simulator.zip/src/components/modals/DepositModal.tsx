import React, { useState } from 'react';
import { QrCode, Copy, Check, Plus, AlertCircle, ShieldAlert } from 'lucide-react';
import { useWallet } from '../../context/WalletContext';

interface DepositModalProps {
  onClose: () => void;
}

export const DepositModal: React.FC<DepositModalProps> = ({ onClose }) => {
  const { tokens, executeDeposit } = useWallet();
  const [selectedSymbol, setSelectedSymbol] = useState<string>('USDT');
  const [copied, setCopied] = useState(false);
  const [customAmount, setCustomAmount] = useState<string>('500');

  const demoAddress = '0x8f4c39174b2169da21b0b5e29c11874b39174b2169da21b0b5e29c11874b39a1';

  const copyAddress = () => {
    navigator.clipboard?.writeText(demoAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSimulateDeposit = (amt: number) => {
    executeDeposit(selectedSymbol, amt, 'Demo Testnet Faucet Credit');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
      <div className="bg-[#181A20] border border-[#2B313A] w-full max-w-sm rounded-t-3xl sm:rounded-2xl p-5 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white text-base">Deposit Crypto</span>
            <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-[#F0B90B]/15 text-[#F0B90B]">
              BNB Chain
            </span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white text-xs px-2 py-1">
            ✕
          </button>
        </div>

        {/* Big Simulation Warning */}
        <div className="p-2.5 rounded-xl bg-red-950/40 border border-red-800/80 flex items-center gap-2 text-xs text-red-200">
          <ShieldAlert className="w-4 h-4 text-red-400 shrink-0" />
          <span>
            SIMULATION ONLY: Do NOT send real cryptocurrency to this simulated address.
          </span>
        </div>

        {/* Token Selector */}
        <div className="space-y-1">
          <span className="text-xs text-slate-400">Select Deposit Asset</span>
          <select
            value={selectedSymbol}
            onChange={e => setSelectedSymbol(e.target.value)}
            className="w-full p-2.5 rounded-xl bg-[#12161F] border border-slate-700 text-white font-bold text-xs focus:outline-none"
          >
            {tokens.map(t => (
              <option key={t.symbol} value={t.symbol} className="bg-[#181A20]">
                {t.name} ({t.symbol})
              </option>
            ))}
          </select>
        </div>

        {/* Simulated QR Code Canvas Box */}
        <div className="p-4 rounded-2xl bg-[#12161F] border border-slate-800 flex flex-col items-center text-center space-y-2">
          {/* Styled SVG QR Code Mockup */}
          <div className="w-32 h-32 bg-white rounded-xl p-2.5 flex items-center justify-center relative shadow-sm">
            <svg viewBox="0 0 100 100" className="w-full h-full text-black">
              {/* Corner position markers */}
              <rect x="5" y="5" width="28" height="28" fill="black" rx="3" />
              <rect x="10" y="10" width="18" height="18" fill="white" rx="2" />
              <rect x="14" y="14" width="10" height="10" fill="black" rx="1" />

              <rect x="67" y="5" width="28" height="28" fill="black" rx="3" />
              <rect x="72" y="10" width="18" height="18" fill="white" rx="2" />
              <rect x="76" y="14" width="10" height="10" fill="black" rx="1" />

              <rect x="5" y="67" width="28" height="28" fill="black" rx="3" />
              <rect x="10" y="72" width="18" height="18" fill="white" rx="2" />
              <rect x="14" y="76" width="10" height="10" fill="black" rx="1" />

              {/* Data blocks */}
              <rect x="38" y="8" width="8" height="8" fill="black" />
              <rect x="50" y="8" width="8" height="8" fill="black" />
              <rect x="38" y="22" width="8" height="8" fill="black" />
              <rect x="50" y="22" width="8" height="8" fill="black" />
              <rect x="8" y="42" width="8" height="8" fill="black" />
              <rect x="22" y="42" width="8" height="8" fill="black" />
              <rect x="38" y="40" width="22" height="22" fill="#F0B90B" rx="3" />
              <rect x="68" y="42" width="8" height="8" fill="black" />
              <rect x="80" y="42" width="8" height="8" fill="black" />
              <rect x="38" y="68" width="8" height="8" fill="black" />
              <rect x="50" y="68" width="8" height="8" fill="black" />
              <rect x="68" y="68" width="8" height="8" fill="black" />
              <rect x="80" y="80" width="12" height="12" fill="black" />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <span className="text-[8px] font-black uppercase tracking-tighter bg-black text-[#F0B90B] px-1 py-0.5 rounded">
                DEMO
              </span>
            </div>
          </div>

          <div className="w-full">
            <span className="text-[10px] text-slate-400 block">Simulated Deposit Address</span>
            <div className="flex items-center justify-between p-2 mt-1 rounded-lg bg-[#181A20] border border-slate-700 text-xs font-mono text-slate-200">
              <span className="truncate max-w-[200px]">{demoAddress}</span>
              <button onClick={copyAddress} className="text-slate-400 hover:text-[#F0B90B]">
                {copied ? <Check className="w-4 h-4 text-[#0ECB81]" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>

        {/* Instant Faucet Top-up options */}
        <div className="space-y-2">
          <span className="text-xs font-semibold text-slate-300 block">
            Instant Testnet Faucet Recharge:
          </span>

          <div className="grid grid-cols-3 gap-2">
            {[100, 500, 1000].map(amt => (
              <button
                key={amt}
                onClick={() => handleSimulateDeposit(amt)}
                className="py-2.5 px-1 rounded-xl bg-slate-800 hover:bg-[#F0B90B] hover:text-black text-white font-bold text-xs transition-colors border border-slate-700 flex items-center justify-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+{amt} {selectedSymbol}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
