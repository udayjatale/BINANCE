import React, { useState, useMemo } from 'react';
import {
  Eye,
  EyeOff,
  Plus,
  Percent,
  Repeat,
  MoreHorizontal,
  Flame,
  TrendingUp,
  TrendingDown,
  Sparkles,
  Star,
  ChevronRight,
  ShieldCheck,
  Zap,
  Settings
} from 'lucide-react';
import { useWallet } from '../../context/WalletContext';
import { Sparkline } from '../common/Sparkline';
import { Token } from '../../types/crypto';
import { USD_TO_INR_RATE } from '../../data/mockTokens';

interface HomeViewProps {
  onOpenDeposit: () => void;
  onOpenTransfer: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({ onOpenDeposit }) => {
  const {
    tokens,
    totalBalanceInr,
    totalBalanceUsd,
    portfolioChange24hInr,
    portfolioChange24hPct,
    primaryCurrency,
    setPrimaryCurrency,
    isBalanceHidden,
    toggleBalanceHidden,
    favorites,
    isFavorite,
    toggleFavorite,
    setSelectedToken,
    setActiveTab,
    setTradeModeTab,
    setIsSettingsOpen
  } = useWallet();

  const [activeMarketTab, setActiveMarketTab] = useState<'favorites' | 'trending' | 'gainers' | 'losers' | 'new'>('trending');
  const [showMoreActions, setShowMoreActions] = useState(false);

  // Filter & sort tokens based on active market tab
  const displayedTokens = useMemo(() => {
    switch (activeMarketTab) {
      case 'favorites':
        return tokens.filter(t => favorites.includes(t.symbol));
      case 'gainers':
        return [...tokens].sort((a, b) => b.change24h - a.change24h);
      case 'losers':
        return [...tokens].sort((a, b) => a.change24h - b.change24h);
      case 'new':
        return tokens.filter(t => t.isFictional || t.category === 'meme' || t.category === 'ai');
      case 'trending':
      default:
        // Hot / high volume tokens
        return [...tokens].sort((a, b) => b.volume24hUsd - a.volume24hUsd);
    }
  }, [tokens, activeMarketTab, favorites]);

  // Top Gainers horizontal banner tokens
  const topGainers = useMemo(() => {
    return [...tokens].sort((a, b) => b.change24h - a.change24h).slice(0, 4);
  }, [tokens]);

  const currencySymbol = primaryCurrency === 'INR' ? '₹' : '$';
  const displayTotal = primaryCurrency === 'INR'
    ? totalBalanceInr.toLocaleString('en-IN')
    : totalBalanceUsd.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  const secondaryEquivalent = primaryCurrency === 'INR'
    ? `$${totalBalanceUsd.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDT`
    : `₹${totalBalanceInr.toLocaleString('en-IN')} INR`;

  const isProfit = portfolioChange24hPct >= 0;

  return (
    <div className="space-y-4 pb-20">
      {/* 1. Main Balance Card inspired by Binance Wallet */}
      <div className="bg-gradient-to-br from-[#181A20] via-[#151922] to-[#12151D] border border-[#2B313A] rounded-2xl p-5 shadow-lg relative overflow-hidden">
        {/* Subtle decorative glow */}
        <div className="absolute -top-12 -right-12 w-36 h-36 bg-[#F0B90B]/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-slate-400">Total Balance</span>
            <button
              onClick={toggleBalanceHidden}
              className="text-slate-400 hover:text-white transition-colors"
              title={isBalanceHidden ? 'Show balance' : 'Hide balance'}
            >
              {isBalanceHidden ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            </button>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-300 bg-[#12161F] px-2.5 py-1 rounded-lg border border-slate-800 font-medium">
            <span className="w-2 h-2 rounded-full bg-[#F0B90B]" />
            <span>Wallet 1</span>
            <span className="text-[10px] text-slate-500">▾</span>
          </div>
        </div>

        {/* Big Balance Number */}
        <div className="flex items-baseline gap-2 my-1">
          {isBalanceHidden ? (
            <div className="text-3xl font-extrabold tracking-wider text-slate-400 select-none py-1">
              ••••••••••
            </div>
          ) : (
            <>
              <span className="text-3xl sm:text-4xl font-extrabold font-mono text-white tracking-tight">
                {currencySymbol}{displayTotal}
              </span>
              <span className="text-xs font-semibold text-slate-400 font-mono">
                {primaryCurrency}
              </span>
            </>
          )}
        </div>

        {/* Secondary equivalent & 24h PnL */}
        <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-800/80">
          <span className="text-slate-400 font-mono">
            {isBalanceHidden ? '••••••' : `≈ ${secondaryEquivalent}`}
          </span>

          <div
            className={`font-semibold font-mono flex items-center gap-1 ${
              isProfit ? 'text-[#0ECB81]' : 'text-[#F6465D]'
            }`}
          >
            <span>Today PnL:</span>
            <span>
              {isProfit ? '+' : ''}
              {primaryCurrency === 'INR' ? `₹${Math.abs(portfolioChange24hInr).toLocaleString('en-IN')}` : `$${(Math.abs(portfolioChange24hInr) / USD_TO_INR_RATE).toFixed(2)}`}
              ({isProfit ? '+' : ''}{portfolioChange24hPct}%)
            </span>
          </div>
        </div>
      </div>

      {/* 2. Primary Action Bar: Add Funds, Earn, Convert, More */}
      <div className="grid grid-cols-4 gap-2 px-1">
        <button
          onClick={onOpenDeposit}
          className="flex flex-col items-center justify-center py-2.5 px-1 rounded-xl bg-[#181A20] hover:bg-[#202530] border border-[#2B313A] transition-all group active:scale-95"
        >
          <div className="w-10 h-10 rounded-full bg-[#F0B90B] flex items-center justify-center text-black font-bold mb-1.5 shadow-sm group-hover:scale-105 transition-transform">
            <Plus className="w-5 h-5" />
          </div>
          <span className="text-xs font-semibold text-white tracking-tight">Add Funds</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('discover');
          }}
          className="flex flex-col items-center justify-center py-2.5 px-1 rounded-xl bg-[#181A20] hover:bg-[#202530] border border-[#2B313A] transition-all group active:scale-95"
        >
          <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-[#F0B90B] font-bold mb-1.5 group-hover:scale-105 transition-transform">
            <Percent className="w-4 h-4" />
          </div>
          <span className="text-xs font-semibold text-white tracking-tight">Earn</span>
        </button>

        <button
          onClick={() => {
            setTradeModeTab('swap');
            setActiveTab('trade');
          }}
          className="flex flex-col items-center justify-center py-2.5 px-1 rounded-xl bg-[#181A20] hover:bg-[#202530] border border-[#2B313A] transition-all group active:scale-95"
        >
          <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-[#0ECB81] font-bold mb-1.5 group-hover:scale-105 transition-transform">
            <Repeat className="w-4 h-4" />
          </div>
          <span className="text-xs font-semibold text-white tracking-tight">Convert</span>
        </button>

        <button
          onClick={() => setShowMoreActions(true)}
          className="flex flex-col items-center justify-center py-2.5 px-1 rounded-xl bg-[#181A20] hover:bg-[#202530] border border-[#2B313A] transition-all group active:scale-95"
        >
          <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 font-bold mb-1.5 group-hover:scale-105 transition-transform">
            <MoreHorizontal className="w-5 h-5" />
          </div>
          <span className="text-xs font-semibold text-white tracking-tight">More</span>
        </button>
      </div>

      {/* 3. Top Gainers Mini Carousel */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-1.5 text-xs font-bold text-white uppercase tracking-wider">
            <Flame className="w-3.5 h-3.5 text-[#F0B90B]" />
            <span>Top Movers</span>
          </div>
          <button
            onClick={() => setActiveTab('markets')}
            className="text-[11px] font-medium text-[#F0B90B] flex items-center hover:underline"
          >
            <span>All Markets</span>
            <ChevronRight className="w-3 h-3" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {topGainers.map(tok => {
            const isPos = tok.change24h >= 0;
            const price = primaryCurrency === 'INR' ? tok.priceInr : tok.priceUsd;
            return (
              <div
                key={tok.symbol}
                onClick={() => setSelectedToken(tok)}
                className="bg-[#181A20] hover:bg-[#1E2329] border border-[#2B313A] rounded-xl p-3 cursor-pointer transition-all active:scale-[0.98]"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-xs text-white">{tok.symbol}</span>
                  <span
                    className={`text-[10px] font-bold font-mono px-1.5 py-0.2 rounded ${
                      isPos ? 'bg-[#0ECB81]/15 text-[#0ECB81]' : 'bg-[#F6465D]/15 text-[#F6465D]'
                    }`}
                  >
                    {isPos ? '+' : ''}{tok.change24h}%
                  </span>
                </div>
                <div className="text-sm font-bold font-mono text-white mt-1">
                  {currencySymbol}{price.toFixed(price < 1 ? 4 : 2)}
                </div>
                <div className="mt-2 flex justify-end">
                  <Sparkline data={tok.sparkline} isPositive={isPos} width={70} height={22} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. Market Tabs: Favorites, Trending, Gainers, Losers, New */}
      <div className="bg-[#181A20] border border-[#2B313A] rounded-2xl overflow-hidden shadow-md">
        <div className="flex items-center overflow-x-auto no-scrollbar border-b border-[#2B313A] px-2 pt-2 bg-[#141824]/50">
          <button
            onClick={() => setActiveMarketTab('favorites')}
            className={`flex items-center gap-1 px-3 py-2 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors ${
              activeMarketTab === 'favorites'
                ? 'border-[#F0B90B] text-[#F0B90B]'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Star className="w-3 h-3" />
            <span>Favorites ({favorites.length})</span>
          </button>
          <button
            onClick={() => setActiveMarketTab('trending')}
            className={`flex items-center gap-1 px-3 py-2 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors ${
              activeMarketTab === 'trending'
                ? 'border-[#F0B90B] text-[#F0B90B]'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Flame className="w-3 h-3" />
            <span>Trending</span>
          </button>
          <button
            onClick={() => setActiveMarketTab('gainers')}
            className={`flex items-center gap-1 px-3 py-2 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors ${
              activeMarketTab === 'gainers'
                ? 'border-[#0ECB81] text-[#0ECB81]'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <TrendingUp className="w-3 h-3" />
            <span>Gainers</span>
          </button>
          <button
            onClick={() => setActiveMarketTab('losers')}
            className={`flex items-center gap-1 px-3 py-2 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors ${
              activeMarketTab === 'losers'
                ? 'border-[#F6465D] text-[#F6465D]'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <TrendingDown className="w-3 h-3" />
            <span>Losers</span>
          </button>
          <button
            onClick={() => setActiveMarketTab('new')}
            className={`flex items-center gap-1 px-3 py-2 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors ${
              activeMarketTab === 'new'
                ? 'border-[#F0B90B] text-[#F0B90B]'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Sparkles className="w-3 h-3" />
            <span>New Tokens</span>
          </button>
        </div>

        {/* Tokens List Rows */}
        <div className="divide-y divide-slate-800/80">
          {displayedTokens.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs">
              {activeMarketTab === 'favorites' ? (
                <div>
                  <Star className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                  <p>No favorite tokens yet.</p>
                  <p className="text-[11px] text-slate-500 mt-1">Tap the star icon next to any token to add it here.</p>
                </div>
              ) : (
                'No tokens found for this category.'
              )}
            </div>
          ) : (
            displayedTokens.map(tok => {
              const isPos = tok.change24h >= 0;
              const price = primaryCurrency === 'INR' ? tok.priceInr : tok.priceUsd;
              const isFav = isFavorite(tok.symbol);

              return (
                <div
                  key={tok.symbol}
                  onClick={() => setSelectedToken(tok)}
                  className="px-4 py-3 hover:bg-[#1E2329]/60 cursor-pointer flex items-center justify-between transition-colors group"
                >
                  {/* Left: Star + Icon + Name */}
                  <div className="flex items-center gap-2.5">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleFavorite(tok.symbol);
                      }}
                      className="p-1 text-slate-500 hover:text-[#F0B90B] transition-colors"
                    >
                      <Star
                        className={`w-3.5 h-3.5 ${
                          isFav ? 'text-[#F0B90B] fill-[#F0B90B]' : ''
                        }`}
                      />
                    </button>

                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white shrink-0"
                      style={{ backgroundColor: tok.iconBg }}
                    >
                      {tok.symbol.slice(0, 3)}
                    </div>

                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-sm text-white">{tok.symbol}</span>
                        <span className="text-[10px] text-slate-500 font-mono">
                          {tok.network?.split(' ')[0] || 'BNB'}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400 block truncate max-w-[110px]">
                        {tok.name}
                      </span>
                    </div>
                  </div>

                  {/* Center: Sparkline */}
                  <div className="hidden sm:block">
                    <Sparkline data={tok.sparkline} isPositive={isPos} width={80} height={26} />
                  </div>

                  {/* Right: Price & 24h Change */}
                  <div className="text-right">
                    <div className="font-bold text-sm font-mono text-white">
                      {currencySymbol}{price.toFixed(price < 1 ? 4 : 2)}
                    </div>
                    <div
                      className={`text-[11px] font-semibold font-mono inline-block px-1.5 py-0.2 rounded mt-0.5 ${
                        isPos
                          ? 'bg-[#0ECB81]/15 text-[#0ECB81]'
                          : 'bg-[#F6465D]/15 text-[#F6465D]'
                      }`}
                    >
                      {isPos ? '+' : ''}{tok.change24h}%
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* "More Actions" Bottom Sheet */}
      {showMoreActions && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-end justify-center p-0 animate-in fade-in">
          <div className="bg-[#181A20] border-t border-[#2B313A] w-full max-w-md rounded-t-3xl p-5 space-y-4">
            <div className="w-10 h-1 bg-slate-700 rounded-full mx-auto mb-2" />
            <div className="flex items-center justify-between pb-2 border-b border-[#2B313A]">
              <h3 className="font-bold text-white text-base">Quick Actions</h3>
              <button
                onClick={() => setShowMoreActions(false)}
                className="text-slate-400 hover:text-white text-xs px-2 py-1"
              >
                Close
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => {
                  setShowMoreActions(false);
                  setTradeModeTab('bridge');
                  setActiveTab('trade');
                }}
                className="p-3 rounded-xl bg-[#12161F] hover:bg-[#202530] border border-slate-800 text-left transition-colors"
              >
                <Repeat className="w-5 h-5 text-[#F0B90B] mb-1.5" />
                <span className="font-semibold text-white block">Cross-Chain Bridge</span>
                <span className="text-[11px] text-slate-400">Simulate L1/L2 transfers</span>
              </button>

              <button
                onClick={() => {
                  setShowMoreActions(false);
                  setTradeModeTab('perps');
                  setActiveTab('trade');
                }}
                className="p-3 rounded-xl bg-[#12161F] hover:bg-[#202530] border border-slate-800 text-left transition-colors"
              >
                <TrendingUp className="w-5 h-5 text-[#0ECB81] mb-1.5" />
                <span className="font-semibold text-white block">Perpetual Futures</span>
                <span className="text-[11px] text-slate-400">Simulate up to 50x leverage</span>
              </button>

              <button
                onClick={() => {
                  setShowMoreActions(false);
                  setActiveTab('assets');
                }}
                className="p-3 rounded-xl bg-[#12161F] hover:bg-[#202530] border border-slate-800 text-left transition-colors"
              >
                <Zap className="w-5 h-5 text-blue-400 mb-1.5" />
                <span className="font-semibold text-white block">Transaction History</span>
                <span className="text-[11px] text-slate-400">View simulated receipts</span>
              </button>

              <button
                onClick={() => {
                  setShowMoreActions(false);
                  onOpenDeposit();
                }}
                className="p-3 rounded-xl bg-[#12161F] hover:bg-[#202530] border border-slate-800 text-left transition-colors"
              >
                <Plus className="w-5 h-5 text-[#F0B90B] mb-1.5" />
                <span className="font-semibold text-white block">Testnet Faucet</span>
                <span className="text-[11px] text-slate-400">Recharge demo balance</span>
              </button>

              <button
                onClick={() => {
                  setShowMoreActions(false);
                  setIsSettingsOpen(true);
                }}
                className="col-span-2 p-3 rounded-xl bg-[#12161F] hover:bg-[#202530] border border-slate-800 text-left transition-colors flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center text-[#F0B90B]">
                    <Settings className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-semibold text-white block text-xs">Settings & Appearance</span>
                    <span className="text-[11px] text-slate-400">Theme (Dark, Light, System), Currency & Data</span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-500" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
