import React, { useState } from 'react';
import {
  Percent,
  Sparkles,
  Calculator,
  ShieldCheck,
  TrendingUp,
  HelpCircle,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import { useWallet } from '../../context/WalletContext';
import { StakingPool, PredictionMarket } from '../../types/crypto';
import { USD_TO_INR_RATE } from '../../data/mockTokens';

export const DiscoverView: React.FC = () => {
  const {
    stakingPools,
    predictionMarkets,
    holdings,
    executeStake,
    stakedPositions,
    executeUnstake,
    claimStakingRewards,
    votePredictionMarket,
    primaryCurrency
  } = useWallet();

  const [activeTab, setActiveTab] = useState<'defi' | 'booster' | 'predictions'>('defi');

  // Calculator State
  const [calcTokenSymbol, setCalcTokenSymbol] = useState<string>('USDT');
  const [calcAmount, setCalcAmount] = useState<string>('500');
  const [calcApy, setCalcApy] = useState<number>(8.5);
  const [calcDurationDays, setCalcDurationDays] = useState<number>(30);

  // Staking Modal State
  const [selectedPoolForStake, setSelectedPoolForStake] = useState<StakingPool | null>(null);
  const [stakeInputAmount, setStakeInputAmount] = useState<string>('100');
  const [stakeMessage, setStakeMessage] = useState<string | null>(null);

  // Prediction Vote Modal State
  const [selectedPrediction, setSelectedPrediction] = useState<PredictionMarket | null>(null);
  const [voteSide, setVoteSide] = useState<'yes' | 'no'>('yes');
  const [voteAmount, setVoteAmount] = useState<string>('25');
  const [voteMessage, setVoteMessage] = useState<string | null>(null);

  const currencySymbol = primaryCurrency === 'INR' ? '₹' : '$';
  const currencyRate = primaryCurrency === 'INR' ? USD_TO_INR_RATE : 1;

  // Calculator projection math
  const parsedCalcAmount = parseFloat(calcAmount) || 0;
  const dailyReturnUsd = (parsedCalcAmount * (calcApy / 100)) / 365;
  const monthlyReturnUsd = dailyReturnUsd * 30;
  const periodReturnUsd = dailyReturnUsd * calcDurationDays;

  // Staking submission
  const handleConfirmStake = () => {
    if (!selectedPoolForStake) return;
    setStakeMessage(null);
    const amt = parseFloat(stakeInputAmount) || 0;
    const res = executeStake(selectedPoolForStake.id, amt);
    if (!res.success) {
      setStakeMessage(res.error || 'Failed to stake.');
    } else {
      setSelectedPoolForStake(null);
      setStakeInputAmount('100');
    }
  };

  // Prediction vote submission
  const handleConfirmVote = () => {
    if (!selectedPrediction) return;
    setVoteMessage(null);
    const amt = parseFloat(voteAmount) || 0;
    const res = votePredictionMarket(selectedPrediction.id, voteSide, amt);
    if (!res.success) {
      setVoteMessage(res.error || 'Vote failed.');
    } else {
      setSelectedPrediction(null);
      setVoteAmount('25');
    }
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Category Tabs: DeFi, Booster, Predictions */}
      <div className="flex items-center gap-1 p-1 bg-[#181A20] rounded-xl border border-[#2B313A]">
        <button
          onClick={() => setActiveTab('defi')}
          className={`flex-1 py-2 text-xs font-bold rounded-lg transition-colors ${
            activeTab === 'defi' ? 'bg-[#F0B90B] text-black shadow-sm' : 'text-slate-400 hover:text-white'
          }`}
        >
          DeFi & Staking
        </button>
        <button
          onClick={() => setActiveTab('booster')}
          className={`flex-1 py-2 text-xs font-bold rounded-lg transition-colors ${
            activeTab === 'booster' ? 'bg-[#F0B90B] text-black shadow-sm' : 'text-slate-400 hover:text-white'
          }`}
        >
          Yield Booster
        </button>
        <button
          onClick={() => setActiveTab('predictions')}
          className={`flex-1 py-2 text-xs font-bold rounded-lg transition-colors ${
            activeTab === 'predictions' ? 'bg-[#F0B90B] text-black shadow-sm' : 'text-slate-400 hover:text-white'
          }`}
        >
          Predictions (DApp)
        </button>
      </div>

      {/* Simulated APY Disclaimer */}
      <div className="px-3 py-2 rounded-xl bg-[#141824] border border-[#2B313A] text-xs text-slate-400 flex items-center gap-2">
        <ShieldCheck className="w-4 h-4 text-[#0ECB81] shrink-0" />
        <span>
          All APYs and yield metrics are simulated estimates for educational demonstration, not guaranteed earnings.
        </span>
      </div>

      {/* TAB 1: DEFI & STAKING */}
      {activeTab === 'defi' && (
        <div className="space-y-4">
          {/* High-Yield Pools List */}
          <div className="space-y-2">
            <h3 className="font-bold text-white text-sm px-1">Available Staking Pools</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {stakingPools.map(pool => (
                <div
                  key={pool.id}
                  className="bg-[#181A20] border border-[#2B313A] hover:border-slate-700 rounded-2xl p-4 space-y-3 transition-colors shadow-sm"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-bold text-white text-sm block">{pool.tokenName}</span>
                      <span className="text-[11px] text-slate-400 font-mono">
                        Lock: {pool.lockType} · Min: {pool.minStake} {pool.tokenSymbol}
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="text-lg font-black font-mono text-[#0ECB81] block">
                        {pool.apy}%
                      </span>
                      <span className="text-[10px] text-slate-400 uppercase font-semibold">
                        Est. APY
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                    <span className="text-slate-400">
                      Balance: {(holdings[pool.tokenSymbol] || 0).toFixed(2)} {pool.tokenSymbol}
                    </span>

                    <button
                      onClick={() => {
                        setSelectedPoolForStake(pool);
                        setStakeMessage(null);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-[#F0B90B] hover:bg-[#FCD535] text-black font-bold text-xs transition-colors"
                    >
                      Stake Demo
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Staking & Yield Calculator */}
          <div className="bg-[#181A20] border border-[#2B313A] rounded-2xl p-4 space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
              <Calculator className="w-4 h-4 text-[#F0B90B]" />
              <h4 className="font-bold text-white text-sm">Demo Staking Calculator</h4>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <span className="text-xs text-slate-400">Investment Amount (USDT)</span>
                <input
                  type="number"
                  value={calcAmount}
                  onChange={e => setCalcAmount(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-[#12161F] border border-slate-800 text-white font-mono text-sm focus:outline-none focus:border-[#F0B90B]"
                />
              </div>

              <div className="space-y-1">
                <span className="text-xs text-slate-400">Lock Period</span>
                <div className="grid grid-cols-4 gap-1">
                  {[
                    { label: 'Flex', days: 30, apy: 8.5 },
                    { label: '30D', days: 30, apy: 12.0 },
                    { label: '60D', days: 60, apy: 16.5 },
                    { label: '90D', days: 90, apy: 22.0 }
                  ].map(p => (
                    <button
                      key={p.label}
                      onClick={() => {
                        setCalcDurationDays(p.days);
                        setCalcApy(p.apy);
                      }}
                      className={`py-2 rounded-lg text-xs font-semibold ${
                        calcDurationDays === p.days && calcApy === p.apy
                          ? 'bg-[#F0B90B] text-black font-bold'
                          : 'bg-[#12161F] text-slate-400 hover:text-white border border-slate-800'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Projected Output Card */}
            <div className="p-3 rounded-xl bg-[#12161F] border border-slate-800 grid grid-cols-3 gap-2 text-center text-xs">
              <div>
                <span className="text-slate-400 text-[11px] block">Daily Reward</span>
                <span className="font-bold font-mono text-[#0ECB81] text-sm mt-0.5 block">
                  ${dailyReturnUsd.toFixed(3)}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">
                  ≈ ₹{(dailyReturnUsd * USD_TO_INR_RATE).toFixed(1)}
                </span>
              </div>
              <div>
                <span className="text-slate-400 text-[11px] block">30-Day Return</span>
                <span className="font-bold font-mono text-[#0ECB81] text-sm mt-0.5 block">
                  ${monthlyReturnUsd.toFixed(2)}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">
                  ≈ ₹{(monthlyReturnUsd * USD_TO_INR_RATE).toFixed(0)}
                </span>
              </div>
              <div>
                <span className="text-slate-400 text-[11px] block">Selected Period</span>
                <span className="font-bold font-mono text-[#0ECB81] text-sm mt-0.5 block">
                  ${periodReturnUsd.toFixed(2)}
                </span>
                <span className="text-[10px] text-slate-500 font-mono">
                  ({calcApy}% APY)
                </span>
              </div>
            </div>
          </div>

          {/* Active Staked Positions */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 px-1">
              My Active Staking ({stakedPositions.length})
            </h4>

            {stakedPositions.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-500 bg-[#181A20] rounded-xl border border-slate-800">
                No active staked positions yet. Choose a pool above to start earning simulated interest.
              </div>
            ) : (
              <div className="space-y-2">
                {stakedPositions.map(pos => (
                  <div
                    key={pos.id}
                    className="p-3 rounded-xl bg-[#181A20] border border-[#2B313A] flex items-center justify-between"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-xs">{pos.poolName}</span>
                        <span className="text-[10px] font-semibold text-[#0ECB81] bg-[#0ECB81]/15 px-1.5 rounded">
                          {pos.apy}% APY
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                        Staked: {pos.amount} {pos.tokenSymbol} · Accrued: +{pos.earnedRewards.toFixed(4)} {pos.tokenSymbol}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => claimStakingRewards(pos.id)}
                        disabled={pos.earnedRewards <= 0}
                        className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-[#F0B90B] font-semibold text-xs transition-colors"
                      >
                        Claim
                      </button>
                      <button
                        onClick={() => executeUnstake(pos.id)}
                        className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition-colors"
                      >
                        Unstake
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: YIELD BOOSTER */}
      {activeTab === 'booster' && (
        <div className="space-y-3">
          <div className="p-4 rounded-2xl bg-gradient-to-r from-[#181A20] to-[#221F14] border border-[#F0B90B]/30 space-y-2">
            <span className="text-[10px] font-bold text-[#F0B90B] uppercase tracking-wider">
              High APY Structured Products
            </span>
            <h3 className="font-bold text-white text-base">Binance Earn & Dual Investment (Demo)</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Target higher yield through structured options simulation. Commit simulated crypto assets with strike targets.
            </p>
          </div>

          <div className="space-y-2">
            {[
              {
                title: 'BTC Buy Low Vault (Strike $88,000)',
                apy: '32.4%',
                period: '7 Days',
                asset: 'USDT'
              },
              {
                title: 'ETH Sell High Vault (Strike $3,600)',
                apy: '28.8%',
                period: '14 Days',
                asset: 'ETH'
              },
              {
                title: 'SOL Turbo Staking Vault',
                apy: '44.5%',
                period: '30 Days',
                asset: 'SOL'
              }
            ].map((vault, i) => (
              <div
                key={i}
                className="p-4 rounded-xl bg-[#181A20] border border-[#2B313A] flex items-center justify-between"
              >
                <div>
                  <h4 className="font-bold text-white text-xs">{vault.title}</h4>
                  <span className="text-[11px] text-slate-400 font-mono">
                    Duration: {vault.period} · Underlying: {vault.asset}
                  </span>
                </div>
                <div className="text-right">
                  <span className="font-black font-mono text-[#0ECB81] text-base block">
                    {vault.apy} APY
                  </span>
                  <button
                    onClick={() => {
                      alert(`Demo Vault "${vault.title}" subscribed with simulated paper credits!`);
                    }}
                    className="mt-1 px-3 py-1 rounded-lg bg-[#F0B90B] text-black font-bold text-xs"
                  >
                    Subscribe Demo
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: PREDICTIONS (DAPP) */}
      {activeTab === 'predictions' && (
        <div className="space-y-3">
          <div className="p-4 rounded-2xl bg-[#181A20] border border-[#2B313A] space-y-1.5">
            <div className="flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-[#F0B90B]" />
              <h3 className="font-bold text-white text-sm">Crypto Prediction Markets (Demo)</h3>
            </div>
            <p className="text-xs text-slate-400">
              Vote on weekly crypto milestones with simulated USDT demo credits.
            </p>
          </div>

          <div className="space-y-3">
            {predictionMarkets.map(m => (
              <div
                key={m.id}
                className="bg-[#181A20] border border-[#2B313A] rounded-xl p-4 space-y-3 shadow-sm"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-[10px] font-semibold text-[#F0B90B] uppercase">
                      {m.category} · Ends {m.endDate}
                    </span>
                    <h4 className="font-bold text-white text-xs mt-0.5 leading-snug">
                      {m.title}
                    </h4>
                  </div>
                </div>

                {/* Pool depth bar */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] font-mono text-slate-400">
                    <span className="text-[#0ECB81]">YES: ${(m.yesPoolUsd / 1000).toFixed(1)}k</span>
                    <span className="text-[#F6465D]">NO: ${(m.noPoolUsd / 1000).toFixed(1)}k</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden flex">
                    <div
                      className="bg-[#0ECB81]"
                      style={{
                        width: `${(m.yesPoolUsd / (m.yesPoolUsd + m.noPoolUsd)) * 100}%`
                      }}
                    />
                    <div
                      className="bg-[#F6465D]"
                      style={{
                        width: `${(m.noPoolUsd / (m.yesPoolUsd + m.noPoolUsd)) * 100}%`
                      }}
                    />
                  </div>
                </div>

                {/* User voted badge */}
                {m.userVote && (
                  <div className="p-2 rounded-lg bg-slate-800/80 text-[11px] text-[#F0B90B] flex items-center justify-between">
                    <span>You placed: {m.userAmount} USDT on {m.userVote.toUpperCase()}</span>
                    <CheckCircle className="w-3.5 h-3.5 text-[#0ECB81]" />
                  </div>
                )}

                {/* Vote buttons */}
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => {
                      setSelectedPrediction(m);
                      setVoteSide('yes');
                      setVoteMessage(null);
                    }}
                    className="py-2 rounded-xl bg-[#0ECB81]/15 hover:bg-[#0ECB81]/25 text-[#0ECB81] font-bold text-xs flex items-center justify-center gap-1 transition-colors border border-[#0ECB81]/30"
                  >
                    <span>Vote YES</span>
                    <span className="font-mono text-[11px]">({m.yesOdds}x)</span>
                  </button>

                  <button
                    onClick={() => {
                      setSelectedPrediction(m);
                      setVoteSide('no');
                      setVoteMessage(null);
                    }}
                    className="py-2 rounded-xl bg-[#F6465D]/15 hover:bg-[#F6465D]/25 text-[#F6465D] font-bold text-xs flex items-center justify-center gap-1 transition-colors border border-[#F6465D]/30"
                  >
                    <span>Vote NO</span>
                    <span className="font-mono text-[11px]">({m.noOdds}x)</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Stake Modal */}
      {selectedPoolForStake && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
          <div className="bg-[#181A20] border border-[#2B313A] w-full max-w-sm rounded-t-3xl sm:rounded-2xl p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#2B313A]">
              <h3 className="font-bold text-white text-base">
                Stake {selectedPoolForStake.tokenSymbol}
              </h3>
              <button
                onClick={() => setSelectedPoolForStake(null)}
                className="text-slate-400 hover:text-white text-xs px-2 py-1"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-xs text-slate-400">
                <span>Amount to Stake</span>
                <span>
                  Avail: {(holdings[selectedPoolForStake.tokenSymbol] || 0).toFixed(2)} {selectedPoolForStake.tokenSymbol}
                </span>
              </div>
              <input
                type="number"
                value={stakeInputAmount}
                onChange={e => setStakeInputAmount(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-[#12161F] border border-slate-700 text-white font-mono text-base focus:outline-none focus:border-[#F0B90B]"
              />
            </div>

            <div className="p-3 rounded-xl bg-[#12161F] border border-slate-800 text-xs space-y-1.5 text-slate-400">
              <div className="flex justify-between">
                <span>APY Reward:</span>
                <span className="font-bold text-[#0ECB81] font-mono">{selectedPoolForStake.apy}%</span>
              </div>
              <div className="flex justify-between">
                <span>Lock Duration:</span>
                <span className="text-slate-300">{selectedPoolForStake.lockType}</span>
              </div>
            </div>

            {stakeMessage && (
              <div className="p-2.5 rounded-lg bg-red-950/40 border border-red-800 text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{stakeMessage}</span>
              </div>
            )}

            <button
              onClick={handleConfirmStake}
              className="w-full py-3 rounded-xl bg-[#F0B90B] hover:bg-[#FCD535] text-black font-bold text-xs transition-colors shadow-md"
            >
              Confirm Demo Staking
            </button>
          </div>
        </div>
      )}

      {/* Prediction Vote Modal */}
      {selectedPrediction && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
          <div className="bg-[#181A20] border border-[#2B313A] w-full max-w-sm rounded-t-3xl sm:rounded-2xl p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#2B313A]">
              <h3 className="font-bold text-white text-base">
                Vote {voteSide.toUpperCase()}
              </h3>
              <button
                onClick={() => setSelectedPrediction(null)}
                className="text-slate-400 hover:text-white text-xs px-2 py-1"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-snug">{selectedPrediction.title}</p>

            <div className="space-y-1">
              <div className="flex justify-between text-xs text-slate-400">
                <span>Vote Stake (USDT)</span>
                <span>Avail: ${(holdings['USDT'] || 0).toFixed(2)} USDT</span>
              </div>
              <input
                type="number"
                value={voteAmount}
                onChange={e => setVoteAmount(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#12161F] border border-slate-700 text-white font-mono text-base focus:outline-none"
              />
            </div>

            {voteMessage && (
              <div className="p-2.5 rounded-lg bg-red-950/40 border border-red-800 text-red-300 text-xs">
                {voteMessage}
              </div>
            )}

            <button
              onClick={handleConfirmVote}
              className={`w-full py-3 rounded-xl font-bold text-xs text-black transition-colors ${
                voteSide === 'yes' ? 'bg-[#0ECB81] hover:bg-[#02C076]' : 'bg-[#F6465D] hover:bg-[#E03149] text-white'
              }`}
            >
              Confirm Vote ({voteSide.toUpperCase()})
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
