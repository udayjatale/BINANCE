import React, { useState, useMemo } from 'react';
import {
  Wallet,
  ArrowDownToLine,
  ArrowUpFromLine,
  ArrowLeftRight,
  RotateCcw,
  Clock,
  ChevronRight,
  TrendingUp,
  ShieldCheck,
  Eye,
  EyeOff
} from 'lucide-react';
import { useWallet } from '../../context/WalletContext';
import { USD_TO_INR_RATE } from '../../data/mockTokens';
import { Transaction } from '../../types/crypto';

interface AssetsViewProps {
  onOpenDeposit: () => void;
  onOpenWithdraw: () => void;
  onOpenTransfer: () => void;
}

export const AssetsView: React.FC<AssetsViewProps> = ({
  onOpenDeposit,
  onOpenWithdraw,
  onOpenTransfer
}) => {
  const {
    holdings,
    tokens,
    totalBalanceInr,
    totalBalanceUsd,
    portfolioChange24hInr,
    portfolioChange24hPct,
    primaryCurrency,
    isBalanceHidden,
    toggleBalanceHidden,
    transactions,
    stakedPositions,
    perpPositions,
    resetDemoWallet,
    setReceiptModalTx,
    setSelectedToken
  } = useWallet();

  const [activeTab, setActiveTab] = useState<'holdings' | 'history'>('holdings');
  const [historyFilter, setHistoryFilter] = useState<'all' | 'swap' | 'deposit' | 'withdraw' | 'stake'>('all');

  const currencySymbol = primaryCurrency === 'INR' ? '₹' : '$';
  const currencyRate = primaryCurrency === 'INR' ? USD_TO_INR_RATE : 1;

  // Compute calculated list of holdings
  const holdingsList = useMemo(() => {
    return Object.entries(holdings)
      .map(([symbol, amount]) => {
        const token = tokens.find(t => t.symbol === symbol);
        const priceUsd = token ? token.priceUsd : (symbol === 'USDT' || symbol === 'USDC' ? 1 : 0);
        const valueUsd = amount * priceUsd;
        const valueInr = valueUsd * USD_TO_INR_RATE;
        return {
          symbol,
          amount,
          token,
          valueUsd,
          valueInr,
          priceUsd
        };
      })
      .filter(item => item.amount > 0.000001)
      .sort((a, b) => b.valueUsd - a.valueUsd);
  }, [holdings, tokens]);

  // Total calculated for percentage distribution
  const totalHoldingsUsd = holdingsList.reduce((acc, curr) => acc + curr.valueUsd, 0) || 1;

  // Filtered transactions
  const filteredTransactions = useMemo(() => {
    if (historyFilter === 'all') return transactions;
    return transactions.filter(tx => tx.type === historyFilter);
  }, [transactions, historyFilter]);

  const displayTotal = primaryCurrency === 'INR'
    ? totalBalanceInr.toLocaleString('en-IN')
    : totalBalanceUsd.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  return (
    <div className="space-y-4 pb-20">
      {/* 1. Main Assets Header Card */}
      <div className="bg-gradient-to-br from-[#181A20] via-[#151922] to-[#12161F] border border-[#2B313A] rounded-2xl p-5 shadow-lg relative overflow-hidden">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-slate-400">Total Net Worth</span>
            <button onClick={toggleBalanceHidden} className="text-slate-400 hover:text-white">
              {isBalanceHidden ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            </button>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 text-xs text-slate-300 bg-[#12161F] px-2.5 py-1 rounded-lg border border-slate-800 font-medium">
              <span className="w-2 h-2 rounded-full bg-[#F0B90B]" />
              <span>Wallet 1</span>
              <span className="text-[10px] text-slate-500">▾</span>
            </div>
            <button
              onClick={() => {
                if (window.confirm('Reset demo portfolio back to the initial ₹100,000 balance?')) {
                  resetDemoWallet();
                }
              }}
              className="p-1 text-slate-500 hover:text-white transition-colors"
              title="Reset portfolio"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="flex items-baseline gap-2 my-1">
          {isBalanceHidden ? (
            <div className="text-3xl font-extrabold text-slate-400 py-1">••••••••••</div>
          ) : (
            <>
              <span className="text-3xl sm:text-4xl font-extrabold font-mono text-white tracking-tight">
                {currencySymbol}{displayTotal}
              </span>
              <span className="text-xs font-semibold text-slate-400 font-mono">
                {primaryCurrency}
              </span>
            </>
          )}
        </div>

        <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-800 text-slate-400 font-mono">
          <span>
            {isBalanceHidden ? '••••••' : (primaryCurrency === 'INR' ? `≈ $${totalBalanceUsd.toFixed(2)} USDT` : `≈ ₹${totalBalanceInr.toLocaleString('en-IN')} INR`)}
          </span>
          <span className={portfolioChange24hPct >= 0 ? 'text-[#0ECB81]' : 'text-[#F6465D]'}>
            24h PnL: {portfolioChange24hPct >= 0 ? '+' : ''}{portfolioChange24hPct}%
          </span>
        </div>
      </div>

      {/* 2. Action Bar: Deposit, Withdraw, Transfer */}
      <div className="grid grid-cols-3 gap-2">
        <button
          onClick={onOpenDeposit}
          className="flex flex-col items-center justify-center py-2.5 rounded-xl bg-[#181A20] hover:bg-[#202530] border border-[#2B313A] transition-all active:scale-95"
        >
          <div className="w-9 h-9 rounded-full bg-[#F0B90B] flex items-center justify-center text-black mb-1">
            <ArrowDownToLine className="w-4 h-4" />
          </div>
          <span className="text-xs font-semibold text-white">Deposit</span>
        </button>

        <button
          onClick={onOpenWithdraw}
          className="flex flex-col items-center justify-center py-2.5 rounded-xl bg-[#181A20] hover:bg-[#202530] border border-[#2B313A] transition-all active:scale-95"
        >
          <div className="w-9 h-9 rounded-full bg-slate-800 flex items-center justify-center text-slate-200 mb-1">
            <ArrowUpFromLine className="w-4 h-4" />
          </div>
          <span className="text-xs font-semibold text-white">Withdraw</span>
        </button>

        <button
          onClick={onOpenTransfer}
          className="flex flex-col items-center justify-center py-2.5 rounded-xl bg-[#181A20] hover:bg-[#202530] border border-[#2B313A] transition-all active:scale-95"
        >
          <div className="w-9 h-9 rounded-full bg-slate-800 flex items-center justify-center text-slate-200 mb-1">
            <ArrowLeftRight className="w-4 h-4" />
          </div>
          <span className="text-xs font-semibold text-white">Transfer</span>
        </button>
      </div>

      {/* 3. Portfolio Allocation Bar */}
      <div className="bg-[#181A20] border border-[#2B313A] rounded-2xl p-4 space-y-3">
        <div className="flex items-center justify-between text-xs">
          <span className="font-bold text-white">Asset Allocation</span>
          <span className="text-slate-400 font-mono text-[11px]">{holdingsList.length} Assets Held</span>
        </div>

        {/* Visual Multi-Segment Bar */}
        <div className="w-full h-3 rounded-full bg-slate-800 overflow-hidden flex">
          {holdingsList.map(item => {
            const pct = (item.valueUsd / totalHoldingsUsd) * 100;
            return (
              <div
                key={item.symbol}
                style={{
                  width: `${pct}%`,
                  backgroundColor: item.token?.color || '#F0B90B'
                }}
                title={`${item.symbol}: ${pct.toFixed(1)}%`}
                className="h-full border-r border-[#0B0E14] last:border-0"
              />
            );
          })}
        </div>

        {/* Legend Chips */}
        <div className="flex items-center flex-wrap gap-2 text-[11px] text-slate-300">
          {holdingsList.slice(0, 5).map(item => {
            const pct = ((item.valueUsd / totalHoldingsUsd) * 100).toFixed(1);
            return (
              <div key={item.symbol} className="flex items-center gap-1.5 font-mono">
                <span
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: item.token?.color || '#F0B90B' }}
                />
                <span>{item.symbol}</span>
                <span className="text-slate-400">{pct}%</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. Sub-tabs: Holdings vs History */}
      <div className="bg-[#181A20] border border-[#2B313A] rounded-2xl overflow-hidden shadow-md">
        <div className="flex items-center border-b border-[#2B313A] bg-[#141824]/60 px-2 pt-2">
          <button
            onClick={() => setActiveTab('holdings')}
            className={`px-4 py-2.5 text-xs font-bold border-b-2 transition-colors ${
              activeTab === 'holdings'
                ? 'border-[#F0B90B] text-[#F0B90B]'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            Crypto Holdings ({holdingsList.length})
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-4 py-2.5 text-xs font-bold border-b-2 transition-colors ${
              activeTab === 'history'
                ? 'border-[#F0B90B] text-[#F0B90B]'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            Transaction History ({transactions.length})
          </button>
        </div>

        {/* TAB A: HOLDINGS LIST */}
        {activeTab === 'holdings' && (
          <div className="divide-y divide-slate-800/80">
            {holdingsList.map(item => {
              const displayVal = primaryCurrency === 'INR'
                ? Math.round(item.valueInr).toLocaleString('en-IN')
                : item.valueUsd.toFixed(2);

              return (
                <div
                  key={item.symbol}
                  onClick={() => {
                    if (item.token) setSelectedToken(item.token);
                  }}
                  className="px-4 py-3 hover:bg-[#1E2329] cursor-pointer flex items-center justify-between transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs text-white shrink-0"
                      style={{ backgroundColor: item.token?.iconBg || '#334155' }}
                    >
                      {item.symbol.slice(0, 3)}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-sm text-white">{item.symbol}</span>
                        <span className="text-[11px] text-slate-400">{item.token?.name}</span>
                      </div>
                      <span className="text-xs text-slate-400 font-mono">
                        {item.amount < 0.0001 ? item.amount.toFixed(6) : item.amount.toFixed(4)} {item.symbol}
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="font-bold font-mono text-sm text-white">
                      {currencySymbol}{displayVal}
                    </div>
                    {item.token && (
                      <div
                        className={`text-[11px] font-mono ${
                          item.token.change24h >= 0 ? 'text-[#0ECB81]' : 'text-[#F6465D]'
                        }`}
                      >
                        {item.token.change24h >= 0 ? '+' : ''}{item.token.change24h}%
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* TAB B: TRANSACTION HISTORY */}
        {activeTab === 'history' && (
          <div>
            {/* Filter pills */}
            <div className="flex items-center gap-1.5 p-2 overflow-x-auto no-scrollbar border-b border-slate-800 text-xs">
              {(['all', 'swap', 'deposit', 'withdraw', 'stake'] as const).map(f => (
                <button
                  key={f}
                  onClick={() => setHistoryFilter(f)}
                  className={`px-2.5 py-1 rounded-lg capitalize font-semibold transition-colors ${
                    historyFilter === f
                      ? 'bg-slate-700 text-white'
                      : 'text-slate-400 hover:text-white bg-[#12161F]'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>

            <div className="divide-y divide-slate-800/80">
              {filteredTransactions.length === 0 ? (
                <div className="py-12 text-center text-xs text-slate-500">
                  No transactions found for this filter.
                </div>
              ) : (
                filteredTransactions.map(tx => (
                  <div
                    key={tx.id}
                    onClick={() => setReceiptModalTx(tx)}
                    className="px-4 py-3 hover:bg-[#1E2329] cursor-pointer flex items-center justify-between transition-colors"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-white">{tx.title}</span>
                        <span className="text-[10px] font-semibold text-[#0ECB81] bg-[#0ECB81]/15 px-1.5 py-0.2 rounded">
                          {tx.status}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                        {new Date(tx.timestamp).toLocaleDateString()} · {tx.network}
                      </div>
                    </div>

                    <div className="text-right flex items-center gap-2">
                      <div>
                        <div className="font-bold font-mono text-xs text-white">
                          ${tx.amountUsd.toFixed(2)}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          ₹{Math.round(tx.amountInr).toLocaleString('en-IN')}
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-500" />
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
