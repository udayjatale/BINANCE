import { Token, StakingPool, PredictionMarket, Transaction, WalletHoldings } from '../types/crypto';

export const USD_TO_INR_RATE = 86.50;

export const INITIAL_TOKENS: Token[] = [
  {
    id: 't-btc',
    symbol: 'BTC',
    name: 'Bitcoin',
    priceUsd: 92450.00,
    priceInr: 92450.00 * USD_TO_INR_RATE,
    change24h: 3.42,
    high24h: 93800.00,
    low24h: 89400.00,
    volume24hUsd: 38400000000,
    marketCapUsd: 1820000000000,
    circulatingSupply: '19.78M BTC',
    allTimeHighUsd: 99800.00,
    category: 'layer1',
    sparkline: [88400, 89100, 89900, 91200, 90800, 91500, 92450],
    color: '#F7931A',
    iconBg: '#F7931A',
    network: 'Bitcoin'
  },
  {
    id: 't-eth',
    symbol: 'ETH',
    name: 'Ethereum',
    priceUsd: 3380.00,
    priceInr: 3380.00 * USD_TO_INR_RATE,
    change24h: -1.18,
    high24h: 3450.00,
    low24h: 3310.00,
    volume24hUsd: 21200000000,
    marketCapUsd: 406000000000,
    circulatingSupply: '120.4M ETH',
    allTimeHighUsd: 4890.00,
    category: 'layer1',
    sparkline: [3480, 3450, 3410, 3390, 3420, 3350, 3380],
    color: '#627EEA',
    iconBg: '#627EEA',
    network: 'Ethereum'
  },
  {
    id: 't-bnb',
    symbol: 'BNB',
    name: 'BNB (Binance)',
    priceUsd: 645.00,
    priceInr: 645.00 * USD_TO_INR_RATE,
    change24h: 2.15,
    high24h: 658.00,
    low24h: 630.00,
    volume24hUsd: 1850000000,
    marketCapUsd: 94000000000,
    circulatingSupply: '145.8M BNB',
    allTimeHighUsd: 720.00,
    category: 'layer1',
    sparkline: [628, 631, 637, 642, 639, 641, 645],
    color: '#F3BA2F',
    iconBg: '#F3BA2F',
    network: 'BNB Smart Chain'
  },
  {
    id: 't-sol',
    symbol: 'SOL',
    name: 'Solana',
    priceUsd: 184.20,
    priceInr: 184.20 * USD_TO_INR_RATE,
    change24h: 6.84,
    high24h: 189.50,
    low24h: 171.20,
    volume24hUsd: 5900000000,
    marketCapUsd: 87000000000,
    circulatingSupply: '472.5M SOL',
    allTimeHighUsd: 260.00,
    category: 'layer1',
    sparkline: [171, 174, 178, 176, 180, 182, 184.2],
    color: '#14F195',
    iconBg: '#14F195',
    network: 'Solana'
  },
  {
    id: 't-xrp',
    symbol: 'XRP',
    name: 'Ripple',
    priceUsd: 2.42,
    priceInr: 2.42 * USD_TO_INR_RATE,
    change24h: -3.45,
    high24h: 2.58,
    low24h: 2.38,
    volume24hUsd: 4200000000,
    marketCapUsd: 138000000000,
    circulatingSupply: '57.1B XRP',
    allTimeHighUsd: 3.84,
    category: 'layer1',
    sparkline: [2.54, 2.51, 2.48, 2.46, 2.43, 2.40, 2.42],
    color: '#23292F',
    iconBg: '#344054',
    network: 'XRP Ledger'
  },
  {
    id: 't-ada',
    symbol: 'ADA',
    name: 'Cardano',
    priceUsd: 0.88,
    priceInr: 0.88 * USD_TO_INR_RATE,
    change24h: 1.45,
    high24h: 0.91,
    low24h: 0.85,
    volume24hUsd: 890000000,
    marketCapUsd: 31200000000,
    circulatingSupply: '35.7B ADA',
    allTimeHighUsd: 3.10,
    category: 'layer1',
    sparkline: [0.86, 0.85, 0.87, 0.86, 0.88, 0.87, 0.88],
    color: '#0033AD',
    iconBg: '#0033AD',
    network: 'Cardano'
  },
  {
    id: 't-doge',
    symbol: 'DOGE',
    name: 'Dogecoin',
    priceUsd: 0.224,
    priceInr: 0.224 * USD_TO_INR_RATE,
    change24h: 8.62,
    high24h: 0.235,
    low24h: 0.201,
    volume24hUsd: 3100000000,
    marketCapUsd: 32800000000,
    circulatingSupply: '147.1B DOGE',
    allTimeHighUsd: 0.73,
    category: 'meme',
    sparkline: [0.201, 0.208, 0.215, 0.212, 0.219, 0.221, 0.224],
    color: '#C2A633',
    iconBg: '#C2A633',
    network: 'Dogecoin'
  },
  {
    id: 't-nex',
    symbol: 'NEX',
    name: 'Nexis Token (NEX)',
    priceUsd: 4.25,
    priceInr: 4.25 * USD_TO_INR_RATE,
    change24h: 14.80,
    high24h: 4.45,
    low24h: 3.65,
    volume24hUsd: 420000000,
    marketCapUsd: 1250000000,
    circulatingSupply: '295.4M NEX',
    allTimeHighUsd: 5.12,
    category: 'layer1',
    sparkline: [3.68, 3.82, 3.95, 4.10, 4.05, 4.18, 4.25],
    color: '#F0B90B',
    iconBg: '#F0B90B',
    network: 'Nexis Chain',
    isFictional: true
  },
  {
    id: 't-aura',
    symbol: 'AURA',
    name: 'Aura Protocol',
    priceUsd: 1.85,
    priceInr: 1.85 * USD_TO_INR_RATE,
    change24h: 18.25,
    high24h: 1.95,
    low24h: 1.52,
    volume24hUsd: 185000000,
    marketCapUsd: 460000000,
    circulatingSupply: '248.6M AURA',
    allTimeHighUsd: 2.80,
    category: 'defi',
    sparkline: [1.55, 1.62, 1.68, 1.74, 1.72, 1.81, 1.85],
    color: '#A855F7',
    iconBg: '#8B5CF6',
    network: 'Ethereum',
    isFictional: true
  },
  {
    id: 't-kryp',
    symbol: 'KRYP',
    name: 'Krypton AI',
    priceUsd: 0.94,
    priceInr: 0.94 * USD_TO_INR_RATE,
    change24h: -5.32,
    high24h: 1.05,
    low24h: 0.91,
    volume24hUsd: 92000000,
    marketCapUsd: 188000000,
    circulatingSupply: '200M KRYP',
    allTimeHighUsd: 1.95,
    category: 'ai',
    sparkline: [1.02, 0.99, 0.98, 0.95, 0.96, 0.92, 0.94],
    color: '#06B6D4',
    iconBg: '#0891B2',
    network: 'Solana',
    isFictional: true
  },
  {
    id: 't-sui',
    symbol: 'SUI',
    name: 'Sui',
    priceUsd: 3.15,
    priceInr: 3.15 * USD_TO_INR_RATE,
    change24h: 5.62,
    high24h: 3.28,
    low24h: 2.92,
    volume24hUsd: 1420000000,
    marketCapUsd: 8900000000,
    circulatingSupply: '2.84B SUI',
    allTimeHighUsd: 3.92,
    category: 'layer1',
    sparkline: [2.95, 3.01, 3.08, 3.04, 3.11, 3.12, 3.15],
    color: '#4DA2FF',
    iconBg: '#4DA2FF',
    network: 'Sui'
  },
  {
    id: 't-pepe',
    symbol: 'PEPE',
    name: 'Pepe',
    priceUsd: 0.0000185,
    priceInr: 0.0000185 * USD_TO_INR_RATE,
    change24h: -4.12,
    high24h: 0.0000198,
    low24h: 0.0000180,
    volume24hUsd: 1980000000,
    marketCapUsd: 7780000000,
    circulatingSupply: '420.69T PEPE',
    allTimeHighUsd: 0.000025,
    category: 'meme',
    sparkline: [0.0000194, 0.0000191, 0.0000189, 0.0000186, 0.0000184, 0.0000183, 0.0000185],
    color: '#22C55E',
    iconBg: '#15803D',
    network: 'Ethereum'
  },
  {
    id: 't-link',
    symbol: 'LINK',
    name: 'Chainlink',
    priceUsd: 19.80,
    priceInr: 19.80 * USD_TO_INR_RATE,
    change24h: 0.75,
    high24h: 20.40,
    low24h: 19.20,
    volume24hUsd: 650000000,
    marketCapUsd: 12200000000,
    circulatingSupply: '608M LINK',
    allTimeHighUsd: 52.88,
    category: 'defi',
    sparkline: [19.5, 19.6, 19.8, 19.7, 19.9, 19.75, 19.8],
    color: '#375BD2',
    iconBg: '#375BD2',
    network: 'Ethereum'
  },
  {
    id: 't-usdt',
    symbol: 'USDT',
    name: 'Tether USD',
    priceUsd: 1.00,
    priceInr: 1.00 * USD_TO_INR_RATE,
    change24h: 0.02,
    high24h: 1.002,
    low24h: 0.999,
    volume24hUsd: 68000000000,
    marketCapUsd: 135000000000,
    circulatingSupply: '135B USDT',
    allTimeHighUsd: 1.05,
    category: 'defi',
    sparkline: [1.00, 1.00, 1.001, 1.00, 0.999, 1.00, 1.00],
    color: '#26A17B',
    iconBg: '#26A17B',
    network: 'Tron'
  },
  {
    id: 't-usdc',
    symbol: 'USDC',
    name: 'USD Coin',
    priceUsd: 1.00,
    priceInr: 1.00 * USD_TO_INR_RATE,
    change24h: -0.01,
    high24h: 1.001,
    low24h: 0.999,
    volume24hUsd: 9400000000,
    marketCapUsd: 44000000000,
    circulatingSupply: '44B USDC',
    allTimeHighUsd: 1.02,
    category: 'defi',
    sparkline: [1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 1.00],
    color: '#2775CA',
    iconBg: '#2775CA',
    network: 'Ethereum'
  }
];

// Initial ₹100,000 Portfolio distribution
export const INITIAL_HOLDINGS: WalletHoldings = {
  USDT: 400,        // 400 * 86.50 = ₹34,600
  BTC: 0.00355,     // 0.00355 * 92,450 * 86.50 = ₹28,389
  ETH: 0.088,       // 0.088 * 3,380 * 86.50 = ₹25,728
  SOL: 0.42,        // 0.42 * 184.20 * 86.50 = ₹6,692
  BNB: 0.095,       // 0.095 * 645 * 86.50 = ₹5,300
  NEX: 50           // 50 * 4.25 * 86.50 = ~₹18,380 bonus fictional token
};

export const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx-001',
    type: 'deposit',
    title: 'Demo Wallet Genesis Grant',
    timestamp: Date.now() - 86400000 * 3,
    status: 'completed',
    toSymbol: 'INR_EQ',
    toAmount: 100000,
    amountUsd: 1156.06,
    amountInr: 100000,
    feeUsd: 0,
    txHash: '0x8f4c39174b2169da21b0b5e29c11874b39174b2169da21b0b5e29c11874b39a1',
    network: 'Nexis Demo Testnet',
    note: 'Initial educational trial allocation of ₹100,000'
  },
  {
    id: 'tx-002',
    type: 'swap',
    title: 'Swap 150 USDT to 0.81 SOL',
    timestamp: Date.now() - 86400000 * 2,
    status: 'completed',
    fromSymbol: 'USDT',
    fromAmount: 150,
    toSymbol: 'SOL',
    toAmount: 0.814,
    amountUsd: 150,
    amountInr: 150 * USD_TO_INR_RATE,
    feeUsd: 0.22,
    txHash: '0x3a79d0124b89cc41893bf10a823b490f3a79d0124b89cc41893bf10a823b490f',
    network: 'Nexis DEX Route v2'
  },
  {
    id: 'tx-003',
    type: 'stake',
    title: 'Staked 100 USDT into Flexible Pool',
    timestamp: Date.now() - 86400000 * 1,
    status: 'completed',
    fromSymbol: 'USDT',
    fromAmount: 100,
    amountUsd: 100,
    amountInr: 100 * USD_TO_INR_RATE,
    feeUsd: 0.05,
    txHash: '0x992b8c56fa7182903e1a8b9c0d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e',
    network: 'Nexis Yield Core'
  }
];

export const INITIAL_STAKING_POOLS: StakingPool[] = [
  {
    id: 'pool-usdt-flex',
    tokenSymbol: 'USDT',
    tokenName: 'Tether USD',
    apy: 8.50,
    durationDays: 'flexible',
    minStake: 10,
    lockType: 'Flexible',
    totalStakedUsd: 48500000,
    riskLevel: 'Low'
  },
  {
    id: 'pool-usdc-flex',
    tokenSymbol: 'USDC',
    tokenName: 'USD Coin',
    apy: 7.80,
    durationDays: 'flexible',
    minStake: 10,
    lockType: 'Flexible',
    totalStakedUsd: 32400000,
    riskLevel: 'Low'
  },
  {
    id: 'pool-sol-liquid',
    tokenSymbol: 'SOL',
    tokenName: 'Solana Staking',
    apy: 7.40,
    durationDays: 'flexible',
    minStake: 0.1,
    lockType: 'Flexible',
    totalStakedUsd: 19800000,
    riskLevel: 'Low'
  },
  {
    id: 'pool-nex-vault',
    tokenSymbol: 'NEX',
    tokenName: 'Nexis Network Vault',
    apy: 18.50,
    durationDays: 30,
    minStake: 5,
    lockType: 'Locked 30D',
    totalStakedUsd: 8400000,
    riskLevel: 'Medium'
  },
  {
    id: 'pool-aura-boost',
    tokenSymbol: 'AURA',
    tokenName: 'Aura Protocol Yield',
    apy: 24.20,
    durationDays: 60,
    minStake: 10,
    lockType: 'Locked 60D',
    totalStakedUsd: 4200000,
    riskLevel: 'High'
  },
  {
    id: 'pool-eth-stake',
    tokenSymbol: 'ETH',
    tokenName: 'Ethereum Beacon',
    apy: 4.60,
    durationDays: 'flexible',
    minStake: 0.01,
    lockType: 'Flexible',
    totalStakedUsd: 65000000,
    riskLevel: 'Low'
  }
];

export const INITIAL_PREDICTION_MARKETS: PredictionMarket[] = [
  {
    id: 'pm-1',
    title: 'Will Bitcoin surpass $98,000 before Sunday 23:59 UTC?',
    category: 'Bitcoin',
    endDate: 'Sunday, 23:59 UTC',
    yesOdds: 1.72,
    noOdds: 2.15,
    yesPoolUsd: 142500,
    noPoolUsd: 98400
  },
  {
    id: 'pm-2',
    title: 'Will Solana daily DEX volume exceed Ethereum mainnet this week?',
    category: 'Ecosystem',
    endDate: 'Friday, 18:00 UTC',
    yesOdds: 2.40,
    noOdds: 1.55,
    yesPoolUsd: 84200,
    noPoolUsd: 126000
  },
  {
    id: 'pm-3',
    title: 'Will total Crypto Market Cap reach $3.5 Trillion this month?',
    category: 'Macro',
    endDate: 'End of Month',
    yesOdds: 1.95,
    noOdds: 1.88,
    yesPoolUsd: 310000,
    noPoolUsd: 295000
  }
];

// Helper to generate realistic historical chart points
export function generateChartData(basePrice: number, timeframe: '1D' | '1W' | '1M' | '1Y' | 'ALL') {
  let pointsCount = 24;
  let volatility = 0.015;
  let stepMs = 3600 * 1000;

  if (timeframe === '1D') {
    pointsCount = 24;
    volatility = 0.012;
    stepMs = 3600 * 1000;
  } else if (timeframe === '1W') {
    pointsCount = 28;
    volatility = 0.025;
    stepMs = 6 * 3600 * 1000;
  } else if (timeframe === '1M') {
    pointsCount = 30;
    volatility = 0.04;
    stepMs = 24 * 3600 * 1000;
  } else if (timeframe === '1Y') {
    pointsCount = 36;
    volatility = 0.08;
    stepMs = 10 * 24 * 3600 * 1000;
  } else {
    pointsCount = 40;
    volatility = 0.12;
    stepMs = 30 * 24 * 3600 * 1000;
  }

  const now = Date.now();
  const startTime = now - pointsCount * stepMs;
  const result: { timestamp: number; price: number; volume: number; open: number; high: number; low: number; close: number }[] = [];

  let currentPrice = basePrice * (1 - volatility * (pointsCount / 4));

  for (let i = 0; i < pointsCount; i++) {
    const time = startTime + i * stepMs;
    const change = (Math.sin(i * 0.7) * 0.5 + (Math.random() - 0.48)) * volatility * currentPrice;
    const open = Math.max(0.00001, currentPrice);
    const close = Math.max(0.00001, open + change);
    const high = Math.max(open, close) + Math.random() * 0.008 * open;
    const low = Math.min(open, close) - Math.random() * 0.008 * open;
    currentPrice = close;

    result.push({
      timestamp: time,
      price: Number(close.toFixed(close < 1 ? 6 : 2)),
      volume: Math.floor(basePrice * 1000 * (0.5 + Math.random())),
      open: Number(open.toFixed(open < 1 ? 6 : 2)),
      high: Number(high.toFixed(high < 1 ? 6 : 2)),
      low: Number(low.toFixed(low < 1 ? 6 : 2)),
      close: Number(close.toFixed(close < 1 ? 6 : 2))
    });
  }

  // Ensure last point matches current price closely
  if (result.length > 0) {
    result[result.length - 1].price = basePrice;
    result[result.length - 1].close = basePrice;
  }

  return result;
}
