import React, { useState } from 'react';
import { WalletProvider, useWallet } from './context/WalletContext';
import { Header } from './components/common/Header';
import { BottomNav } from './components/common/BottomNav';
import { HomeView } from './components/home/HomeView';
import { MarketsView } from './components/markets/MarketsView';
import { TradeView } from './components/trade/TradeView';
import { DiscoverView } from './components/discover/DiscoverView';
import { AssetsView } from './components/assets/AssetsView';
import { TokenDetailModal } from './components/markets/TokenDetailModal';
import { DepositModal } from './components/modals/DepositModal';
import { WithdrawModal } from './components/modals/WithdrawModal';
import { TransferModal } from './components/modals/TransferModal';
import { ReceiptModal } from './components/modals/ReceiptModal';
import { SettingsModal } from './components/modals/SettingsModal';
import { Smartphone, Monitor } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const {
    activeTab,
    selectedToken,
    setSelectedToken,
    receiptModalTx,
    setReceiptModalTx,
    isSettingsOpen,
    setIsSettingsOpen
  } = useWallet();

  // Modals
  const [isDepositOpen, setIsDepositOpen] = useState(false);
  const [isWithdrawOpen, setIsWithdrawOpen] = useState(false);
  const [isTransferOpen, setIsTransferOpen] = useState(false);

  // Desktop view mode toggle: 'phone' (framed mobile container) vs 'expanded'
  const [viewMode, setViewMode] = useState<'phone' | 'expanded'>('phone');

  return (
    <div className="min-h-screen bg-[#0B0E14] text-slate-100 flex flex-col items-center justify-start">
      {/* Top Device View Toggle Bar for Desktop users */}
      <div className="hidden lg:flex w-full bg-[#12161F] border-b border-[#1E2329] px-6 py-1.5 items-center justify-between text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-white">Binance Web3 Wallet</span>
          <span>· Mobile Experience</span>
        </div>

        <div className="flex items-center gap-1 bg-[#181A20] p-1 rounded-lg border border-slate-800">
          <button
            onClick={() => setViewMode('phone')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-semibold transition-colors ${
              viewMode === 'phone'
                ? 'bg-[#F0B90B] text-black shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Mobile Frame</span>
          </button>
          <button
            onClick={() => setViewMode('expanded')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-semibold transition-colors ${
              viewMode === 'expanded'
                ? 'bg-[#F0B90B] text-black shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>Expanded View</span>
          </button>
        </div>
      </div>

      {/* Main Container */}
      <div
        className={`w-full flex-1 flex flex-col transition-all duration-200 ${
          viewMode === 'phone'
            ? 'max-w-md lg:my-4 lg:rounded-3xl lg:border lg:border-[#2B313A] lg:shadow-2xl lg:overflow-hidden lg:ring-8 lg:ring-slate-900/40 bg-[#0B0E14]'
            : 'max-w-4xl px-4 py-2 bg-[#0B0E14]'
        }`}
      >
        {/* Top Header */}
        <Header />

        {/* Active Tab Screen Content */}
        <main className="flex-1 p-4 overflow-y-auto">
          {activeTab === 'home' && (
            <HomeView
              onOpenDeposit={() => setIsDepositOpen(true)}
              onOpenTransfer={() => setIsTransferOpen(true)}
            />
          )}

          {activeTab === 'markets' && <MarketsView />}

          {activeTab === 'trade' && <TradeView />}

          {activeTab === 'discover' && <DiscoverView />}

          {activeTab === 'assets' && (
            <AssetsView
              onOpenDeposit={() => setIsDepositOpen(true)}
              onOpenWithdraw={() => setIsWithdrawOpen(true)}
              onOpenTransfer={() => setIsTransferOpen(true)}
            />
          )}
        </main>

        {/* Bottom Navigation */}
        <BottomNav />
      </div>

      {/* Modals */}
      {selectedToken && (
        <TokenDetailModal
          token={selectedToken}
          onClose={() => setSelectedToken(null)}
        />
      )}

      {isDepositOpen && (
        <DepositModal onClose={() => setIsDepositOpen(false)} />
      )}

      {isWithdrawOpen && (
        <WithdrawModal onClose={() => setIsWithdrawOpen(false)} />
      )}

      {isTransferOpen && (
        <TransferModal onClose={() => setIsTransferOpen(false)} />
      )}

      {receiptModalTx && (
        <ReceiptModal
          transaction={receiptModalTx}
          onClose={() => setReceiptModalTx(null)}
        />
      )}

      {isSettingsOpen && (
        <SettingsModal onClose={() => setIsSettingsOpen(false)} />
      )}
    </div>
  );
};

export default function App() {
  return (
    <WalletProvider>
      <MainAppContent />
    </WalletProvider>
  );
}
