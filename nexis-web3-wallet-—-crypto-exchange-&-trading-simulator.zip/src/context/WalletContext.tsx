import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import {
  Token,
  WalletHoldings,
  Transaction,
  StakedPosition,
  PerpPosition,
  StakingPool,
  PredictionMarket
} from '../types/crypto';
import {
  INITIAL_TOKENS,
  INITIAL_HOLDINGS,
  INITIAL_TRANSACTIONS,
  INITIAL_STAKING_POOLS,
  INITIAL_PREDICTION_MARKETS,
  USD_TO_INR_RATE
} from '../data/mockTokens';

export type ThemeMode = 'dark' | 'light' | 'system';

interface WalletContextType {
  tokens: Token[];
  holdings: WalletHoldings;
  transactions: Transaction[];
  stakedPositions: StakedPosition[];
  perpPositions: PerpPosition[];
  stakingPools: StakingPool[];
  predictionMarkets: PredictionMarket[];
  favorites: string[];
  primaryCurrency: 'INR' | 'USDT';
  setPrimaryCurrency: (curr: 'INR' | 'USDT') => void;
  isBalanceHidden: boolean;
  toggleBalanceHidden: () => void;
  totalBalanceUsd: number;
  totalBalanceInr: number;
  portfolioChange24hInr: number;
  portfolioChange24hPct: number;
  selectedToken: Token | null;
  setSelectedToken: (token: Token | null) => void;
  activeTab: 'home' | 'markets' | 'trade' | 'discover' | 'assets';
  setActiveTab: (tab: 'home' | 'markets' | 'trade' | 'discover' | 'assets') => void;
  tradePresetToken: Token | null;
  setTradePresetToken: (token: Token | null) => void;
  tradeModeTab: 'swap' | 'bridge' | 'pro' | 'perps';
  setTradeModeTab: (mode: 'swap' | 'bridge' | 'pro' | 'perps') => void;
  toggleFavorite: (symbol: string) => void;
  isFavorite: (symbol: string) => boolean;
  getToken: (symbol: string) => Token | undefined;
  executeSwap: (
    fromSymbol: string,
    toSymbol: string,
    fromAmount: number,
    toAmount: number,
    feeUsd: number
  ) => { success: boolean; tx?: Transaction; error?: string };
  executeDeposit: (tokenSymbol: string, amount: number, note?: string) => Transaction;
  executeWithdraw: (
    tokenSymbol: string,
    amount: number,
    address: string,
    network: string
  ) => { success: boolean; tx?: Transaction; error?: string };
  executeStake: (poolId: string, amount: number) => { success: boolean; error?: string };
  executeUnstake: (stakedId: string) => { success: boolean; error?: string };
  claimStakingRewards: (stakedId: string) => { success: boolean; error?: string };
  openPerpPosition: (
    symbol: string,
    side: 'long' | 'short',
    leverage: number,
    marginUsd: number
  ) => { success: boolean; error?: string };
  closePerpPosition: (positionId: string) => { success: boolean; pnlUsd: number; error?: string };
  votePredictionMarket: (
    marketId: string,
    option: 'yes' | 'no',
    amountUsd: number
  ) => { success: boolean; error?: string };
  resetDemoWallet: () => void;
  addFaucetFunds: (symbol?: string, amount?: number) => void;
  receiptModalTx: Transaction | null;
  setReceiptModalTx: (tx: Transaction | null) => void;
  isPriceTicking: boolean;
  togglePriceTicking: () => void;
  theme: ThemeMode;
  setTheme: (mode: ThemeMode) => void;
  effectiveTheme: 'dark' | 'light';
  isSettingsOpen: boolean;
  setIsSettingsOpen: (open: boolean) => void;
}

const STORAGE_KEYS = {
  HOLDINGS: 'nexis_demo_holdings_v2',
  TRANSACTIONS: 'nexis_demo_transactions_v2',
  FAVORITES: 'nexis_demo_favorites_v2',
  STAKED: 'nexis_demo_staked_v2',
  PERPS: 'nexis_demo_perps_v2',
  PREDICTIONS: 'nexis_demo_predictions_v2',
  PRIMARY_CURRENCY: 'nexis_demo_primary_currency',
  BALANCE_HIDDEN: 'nexis_demo_balance_hidden',
  THEME: 'binance_wallet_theme_preference'
};

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export const WalletProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [tokens, setTokens] = useState<Token[]>(INITIAL_TOKENS);
  const [isPriceTicking, setIsPriceTicking] = useState<boolean>(true);

  // Initialize holdings from localStorage or defaults
  const [holdings, setHoldings] = useState<WalletHoldings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.HOLDINGS);
      return saved ? JSON.parse(saved) : INITIAL_HOLDINGS;
    } catch {
      return INITIAL_HOLDINGS;
    }
  });

  // Transactions
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
      return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
    } catch {
      return INITIAL_TRANSACTIONS;
    }
  });

  // Favorites
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.FAVORITES);
      return saved ? JSON.parse(saved) : ['BTC', 'ETH', 'SOL', 'NEX'];
    } catch {
      return ['BTC', 'ETH', 'SOL', 'NEX'];
    }
  });

  // Staked positions
  const [stakedPositions, setStakedPositions] = useState<StakedPosition[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.STAKED);
      if (saved) return JSON.parse(saved);
      return [
        {
          id: 'stake-init-1',
          tokenSymbol: 'USDT',
          poolName: 'Flexible USDT High Yield',
          amount: 100,
          apy: 8.5,
          durationDays: 'flexible',
          startDate: Date.now() - 86400000 * 2,
          earnedRewards: 0.046,
          status: 'active'
        }
      ];
    } catch {
      return [];
    }
  });

  // Perpetual Futures positions
  const [perpPositions, setPerpPositions] = useState<PerpPosition[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PERPS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Prediction markets
  const [predictionMarkets, setPredictionMarkets] = useState<PredictionMarket[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PREDICTIONS);
      return saved ? JSON.parse(saved) : INITIAL_PREDICTION_MARKETS;
    } catch {
      return INITIAL_PREDICTION_MARKETS;
    }
  });

  // Currency preference (INR / USDT)
  const [primaryCurrency, setPrimaryCurrencyState] = useState<'INR' | 'USDT'>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PRIMARY_CURRENCY);
      return (saved === 'USDT' || saved === 'INR') ? saved : 'INR';
    } catch {
      return 'INR';
    }
  });

  const setPrimaryCurrency = (curr: 'INR' | 'USDT') => {
    setPrimaryCurrencyState(curr);
    localStorage.setItem(STORAGE_KEYS.PRIMARY_CURRENCY, curr);
  };

  // Balance hidden
  const [isBalanceHidden, setIsBalanceHidden] = useState<boolean>(() => {
    try {
      return localStorage.getItem(STORAGE_KEYS.BALANCE_HIDDEN) === 'true';
    } catch {
      return false;
    }
  });

  const toggleBalanceHidden = () => {
    setIsBalanceHidden(prev => {
      const next = !prev;
      localStorage.setItem(STORAGE_KEYS.BALANCE_HIDDEN, String(next));
      return next;
    });
  };

  // Theme Preference: 'dark' | 'light' | 'system'
  const [theme, setThemeState] = useState<ThemeMode>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.THEME);
      return (saved === 'dark' || saved === 'light' || saved === 'system') ? saved : 'dark';
    } catch {
      return 'dark';
    }
  });

  const [effectiveTheme, setEffectiveTheme] = useState<'dark' | 'light'>('dark');
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);

  // Sync and apply theme to document root
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');

    const updateTheme = () => {
      let active: 'dark' | 'light' = 'dark';
      if (theme === 'system') {
        active = mediaQuery.matches ? 'dark' : 'light';
      } else {
        active = theme;
      }

      setEffectiveTheme(active);

      const root = document.documentElement;
      if (active === 'dark') {
        root.classList.add('dark');
        root.classList.remove('light');
        root.setAttribute('data-theme', 'dark');
        root.style.colorScheme = 'dark';
      } else {
        root.classList.remove('dark');
        root.classList.add('light');
        root.setAttribute('data-theme', 'light');
        root.style.colorScheme = 'light';
      }
    };

    updateTheme();

    const handleSystemChange = () => {
      if (theme === 'system') {
        updateTheme();
      }
    };

    mediaQuery.addEventListener('change', handleSystemChange);
    return () => mediaQuery.removeEventListener('change', handleSystemChange);
  }, [theme]);

  const setTheme = (newTheme: ThemeMode) => {
    setThemeState(newTheme);
    try {
      localStorage.setItem(STORAGE_KEYS.THEME, newTheme);
    } catch (e) {
      console.error(e);
    }
  };

  // Navigation & Modals
  const [activeTab, setActiveTab] = useState<'home' | 'markets' | 'trade' | 'discover' | 'assets'>('home');
  const [tradeModeTab, setTradeModeTab] = useState<'swap' | 'bridge' | 'pro' | 'perps'>('swap');
  const [selectedToken, setSelectedToken] = useState<Token | null>(null);
  const [tradePresetToken, setTradePresetToken] = useState<Token | null>(null);
  const [receiptModalTx, setReceiptModalTx] = useState<Transaction | null>(null);

  // Sync state to LocalStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.HOLDINGS, JSON.stringify(holdings));
  }, [holdings]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.STAKED, JSON.stringify(stakedPositions));
  }, [stakedPositions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PERPS, JSON.stringify(perpPositions));
  }, [perpPositions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PREDICTIONS, JSON.stringify(predictionMarkets));
  }, [predictionMarkets]);

  // Periodic Realistic Price Movement Simulation
  useEffect(() => {
    if (!isPriceTicking) return;

    const interval = setInterval(() => {
      setTokens(prevTokens => {
        return prevTokens.map(tok => {
          if (tok.symbol === 'USDT' || tok.symbol === 'USDC') {
            return tok; // Stablecoins stay anchored
          }

          // Random walk delta: -0.25% to +0.28%
          const deltaPct = (Math.random() - 0.48) * 0.005;
          const newPriceUsd = Math.max(0.000001, tok.priceUsd * (1 + deltaPct));
          const newPriceInr = newPriceUsd * USD_TO_INR_RATE;
          const newChange24h = Number((tok.change24h + deltaPct * 15).toFixed(2));

          const updatedSparkline = [...tok.sparkline.slice(1), newPriceUsd];

          return {
            ...tok,
            priceUsd: Number(newPriceUsd.toFixed(newPriceUsd < 1 ? 6 : 2)),
            priceInr: Number(newPriceInr.toFixed(newPriceInr < 1 ? 4 : 2)),
            change24h: newChange24h,
            high24h: Math.max(tok.high24h, newPriceUsd),
            low24h: Math.min(tok.low24h, newPriceUsd),
            sparkline: updatedSparkline
          };
        });
      });

      // Also gently accrue staking rewards
      setStakedPositions(prevStakes =>
        prevStakes.map(stk => {
          if (stk.status !== 'active') return stk;
          // Accrue micro reward: (amount * APY / 365 / 86400) * intervalSeconds
          const secondReward = (stk.amount * (stk.apy / 100)) / (365 * 86400) * 4;
          return {
            ...stk,
            earnedRewards: Number((stk.earnedRewards + secondReward).toFixed(6))
          };
        })
      );
    }, 3800);

    return () => clearInterval(interval);
  }, [isPriceTicking]);

  // Helper to get token
  const getToken = useCallback(
    (symbol: string): Token | undefined => {
      return tokens.find(t => t.symbol.toUpperCase() === symbol.toUpperCase());
    },
    [tokens]
  );

  // Total Balances Calculation
  const { totalBalanceUsd, totalBalanceInr, portfolioChange24hInr, portfolioChange24hPct } = useMemo(() => {
    let usdSum = 0;
    let weightedChange = 0;

    // Spot holdings
    Object.entries(holdings).forEach(([symbol, amount]) => {
      if (amount <= 0) return;
      const token = getToken(symbol);
      const price = token ? token.priceUsd : 1;
      const valueUsd = amount * price;
      usdSum += valueUsd;
      weightedChange += valueUsd * ((token?.change24h || 0) / 100);
    });

    // Staked positions
    stakedPositions.forEach(stk => {
      if (stk.status !== 'active') return;
      const token = getToken(stk.tokenSymbol);
      const price = token ? token.priceUsd : 1;
      const stakedValue = (stk.amount + stk.earnedRewards) * price;
      usdSum += stakedValue;
    });

    // Futures Margin
    perpPositions.forEach(perp => {
      usdSum += perp.marginUsd;
    });

    const inrSum = usdSum * USD_TO_INR_RATE;
    const changeInr = weightedChange * USD_TO_INR_RATE;
    const changePct = usdSum > 0 ? (weightedChange / usdSum) * 100 : 0;

    return {
      totalBalanceUsd: Number(usdSum.toFixed(2)),
      totalBalanceInr: Math.round(inrSum),
      portfolioChange24hInr: Math.round(changeInr),
      portfolioChange24hPct: Number(changePct.toFixed(2))
    };
  }, [holdings, stakedPositions, perpPositions, tokens, getToken]);

  // Favorite toggle
  const toggleFavorite = (symbol: string) => {
    setFavorites(prev => {
      const exists = prev.includes(symbol);
      if (exists) {
        return prev.filter(s => s !== symbol);
      } else {
        return [...prev, symbol];
      }
    });
  };

  const isFavorite = (symbol: string) => favorites.includes(symbol);

  // Swap Execution
  const executeSwap = (
    fromSymbol: string,
    toSymbol: string,
    fromAmount: number,
    toAmount: number,
    feeUsd: number
  ) => {
    if (fromAmount <= 0) {
      return { success: false, error: 'Enter a valid amount to swap.' };
    }
    const currentFromBalance = holdings[fromSymbol] || 0;
    if (currentFromBalance < fromAmount) {
      return {
        success: false,
        error: `Insufficient ${fromSymbol} balance. Available: ${currentFromBalance.toFixed(4)}`
      };
    }

    const fromToken = getToken(fromSymbol);
    const toToken = getToken(toSymbol);

    // Update holdings
    setHoldings(prev => {
      const next = { ...prev };
      next[fromSymbol] = Math.max(0, (next[fromSymbol] || 0) - fromAmount);
      next[toSymbol] = (next[toSymbol] || 0) + toAmount;
      return next;
    });

    const amountUsd = fromAmount * (fromToken?.priceUsd || 1);
    const amountInr = amountUsd * USD_TO_INR_RATE;

    const newTx: Transaction = {
      id: `tx-swap-${Date.now()}`,
      type: 'swap',
      title: `Swap ${fromAmount.toFixed(4)} ${fromSymbol} → ${toAmount.toFixed(4)} ${toSymbol}`,
      timestamp: Date.now(),
      status: 'completed',
      fromSymbol,
      fromAmount,
      toSymbol,
      toAmount,
      amountUsd,
      amountInr,
      feeUsd,
      txHash: '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
      network: 'Nexis Liquidity Protocol'
    };

    setTransactions(prev => [newTx, ...prev]);
    setReceiptModalTx(newTx);

    return { success: true, tx: newTx };
  };

  // Deposit Simulation
  const executeDeposit = (tokenSymbol: string, amount: number, note?: string): Transaction => {
    const token = getToken(tokenSymbol);
    const priceUsd = token ? token.priceUsd : 1;
    const amountUsd = amount * priceUsd;
    const amountInr = amountUsd * USD_TO_INR_RATE;

    setHoldings(prev => ({
      ...prev,
      [tokenSymbol]: (prev[tokenSymbol] || 0) + amount
    }));

    const newTx: Transaction = {
      id: `tx-dep-${Date.now()}`,
      type: 'deposit',
      title: `Demo Deposit +${amount} ${tokenSymbol}`,
      timestamp: Date.now(),
      status: 'completed',
      toSymbol: tokenSymbol,
      toAmount: amount,
      amountUsd,
      amountInr,
      feeUsd: 0,
      txHash: '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
      network: token?.network || 'Nexis Demo Net',
      note: note || 'Simulated Testnet Faucet Credit'
    };

    setTransactions(prev => [newTx, ...prev]);
    setReceiptModalTx(newTx);
    return newTx;
  };

  // Withdraw Simulation
  const executeWithdraw = (
    tokenSymbol: string,
    amount: number,
    address: string,
    network: string
  ) => {
    const currentBal = holdings[tokenSymbol] || 0;
    if (amount <= 0) return { success: false, error: 'Enter a valid amount.' };
    if (currentBal < amount) return { success: false, error: `Insufficient ${tokenSymbol} balance.` };
    if (!address || address.length < 10) return { success: false, error: 'Enter a valid destination address.' };

    const token = getToken(tokenSymbol);
    const priceUsd = token ? token.priceUsd : 1;
    const feeUsd = 1.50; // demo network gas
    const amountUsd = amount * priceUsd;
    const amountInr = amountUsd * USD_TO_INR_RATE;

    setHoldings(prev => ({
      ...prev,
      [tokenSymbol]: Math.max(0, (prev[tokenSymbol] || 0) - amount)
    }));

    const newTx: Transaction = {
      id: `tx-wd-${Date.now()}`,
      type: 'withdraw',
      title: `Demo Withdraw ${amount} ${tokenSymbol}`,
      timestamp: Date.now(),
      status: 'completed',
      fromSymbol: tokenSymbol,
      fromAmount: amount,
      amountUsd,
      amountInr,
      feeUsd,
      txHash: '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
      network,
      note: `Sent to ${address.slice(0, 6)}...${address.slice(-4)} (Demo Simulation)`
    };

    setTransactions(prev => [newTx, ...prev]);
    setReceiptModalTx(newTx);
    return { success: true, tx: newTx };
  };

  // Staking
  const executeStake = (poolId: string, amount: number) => {
    const pool = INITIAL_STAKING_POOLS.find(p => p.id === poolId);
    if (!pool) return { success: false, error: 'Staking pool not found.' };

    const currentBal = holdings[pool.tokenSymbol] || 0;
    if (amount < pool.minStake) {
      return { success: false, error: `Minimum stake requirement is ${pool.minStake} ${pool.tokenSymbol}.` };
    }
    if (currentBal < amount) {
      return { success: false, error: `Insufficient ${pool.tokenSymbol} balance.` };
    }

    // Deduct spot balance
    setHoldings(prev => ({
      ...prev,
      [pool.tokenSymbol]: Math.max(0, (prev[pool.tokenSymbol] || 0) - amount)
    }));

    const newStake: StakedPosition = {
      id: `stake-${Date.now()}`,
      tokenSymbol: pool.tokenSymbol,
      poolName: `${pool.lockType} ${pool.tokenName}`,
      amount,
      apy: pool.apy,
      durationDays: pool.durationDays,
      startDate: Date.now(),
      earnedRewards: 0,
      status: 'active'
    };

    setStakedPositions(prev => [newStake, ...prev]);

    const token = getToken(pool.tokenSymbol);
    const amountUsd = amount * (token?.priceUsd || 1);

    const tx: Transaction = {
      id: `tx-stk-${Date.now()}`,
      type: 'stake',
      title: `Staked ${amount} ${pool.tokenSymbol} (${pool.apy}% APY)`,
      timestamp: Date.now(),
      status: 'completed',
      fromSymbol: pool.tokenSymbol,
      fromAmount: amount,
      amountUsd,
      amountInr: amountUsd * USD_TO_INR_RATE,
      feeUsd: 0.05,
      txHash: '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
      network: 'Nexis Yield Core'
    };
    setTransactions(prev => [tx, ...prev]);
    setReceiptModalTx(tx);

    return { success: true };
  };

  const executeUnstake = (stakedId: string) => {
    const stake = stakedPositions.find(s => s.id === stakedId);
    if (!stake || stake.status !== 'active') return { success: false, error: 'Position not found or already unstaked.' };

    const totalReturn = stake.amount + stake.earnedRewards;

    // Return to spot balance
    setHoldings(prev => ({
      ...prev,
      [stake.tokenSymbol]: (prev[stake.tokenSymbol] || 0) + totalReturn
    }));

    setStakedPositions(prev => prev.filter(s => s.id !== stakedId));

    const token = getToken(stake.tokenSymbol);
    const amountUsd = totalReturn * (token?.priceUsd || 1);

    const tx: Transaction = {
      id: `tx-unstk-${Date.now()}`,
      type: 'unstake',
      title: `Unstaked ${stake.amount} ${stake.tokenSymbol} + ${stake.earnedRewards.toFixed(4)} Rewards`,
      timestamp: Date.now(),
      status: 'completed',
      toSymbol: stake.tokenSymbol,
      toAmount: totalReturn,
      amountUsd,
      amountInr: amountUsd * USD_TO_INR_RATE,
      feeUsd: 0,
      txHash: '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
      network: 'Nexis Yield Core'
    };
    setTransactions(prev => [tx, ...prev]);
    return { success: true };
  };

  const claimStakingRewards = (stakedId: string) => {
    const stake = stakedPositions.find(s => s.id === stakedId);
    if (!stake || stake.earnedRewards <= 0) return { success: false, error: 'No rewards available to claim.' };

    const reward = stake.earnedRewards;

    setHoldings(prev => ({
      ...prev,
      [stake.tokenSymbol]: (prev[stake.tokenSymbol] || 0) + reward
    }));

    setStakedPositions(prev =>
      prev.map(s => (s.id === stakedId ? { ...s, earnedRewards: 0 } : s))
    );

    return { success: true };
  };

  // Perpetual Futures
  const openPerpPosition = (
    symbol: string,
    side: 'long' | 'short',
    leverage: number,
    marginUsd: number
  ) => {
    const usdtBalance = holdings['USDT'] || 0;
    if (marginUsd <= 0) return { success: false, error: 'Margin must be greater than $0.' };
    if (usdtBalance < marginUsd) return { success: false, error: `Insufficient USDT margin. Available: $${usdtBalance.toFixed(2)}` };

    const baseSymbol = symbol.split('/')[0];
    const token = getToken(baseSymbol);
    if (!token) return { success: false, error: 'Invalid market token.' };

    const entryPrice = token.priceUsd;
    const notionalUsd = marginUsd * leverage;
    const sizeTokens = notionalUsd / entryPrice;

    // Liquidation price approx: 1/leverage buffer
    const liqDropPct = 0.90 / leverage;
    const liquidationPrice = side === 'long'
      ? entryPrice * (1 - liqDropPct)
      : entryPrice * (1 + liqDropPct);

    // Deduct USDT margin
    setHoldings(prev => ({
      ...prev,
      USDT: Math.max(0, (prev.USDT || 0) - marginUsd)
    }));

    const newPosition: PerpPosition = {
      id: `perp-${Date.now()}`,
      symbol,
      side,
      leverage,
      entryPrice,
      markPrice: entryPrice,
      marginUsd,
      sizeTokens,
      liquidationPrice,
      timestamp: Date.now()
    };

    setPerpPositions(prev => [newPosition, ...prev]);

    const tx: Transaction = {
      id: `tx-perp-${Date.now()}`,
      type: 'perp_open',
      title: `Open ${leverage}x ${side.toUpperCase()} ${symbol}`,
      timestamp: Date.now(),
      status: 'completed',
      amountUsd: marginUsd,
      amountInr: marginUsd * USD_TO_INR_RATE,
      feeUsd: marginUsd * 0.0006,
      txHash: '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
      network: 'Nexis Perps v3 Engine'
    };
    setTransactions(prev => [tx, ...prev]);

    return { success: true };
  };

  const closePerpPosition = (positionId: string) => {
    const pos = perpPositions.find(p => p.id === positionId);
    if (!pos) return { success: false, pnlUsd: 0, error: 'Position not found.' };

    const baseSymbol = pos.symbol.split('/')[0];
    const token = getToken(baseSymbol);
    const currentPrice = token ? token.priceUsd : pos.entryPrice;

    // Calculate PnL
    const priceChangePct = (currentPrice - pos.entryPrice) / pos.entryPrice;
    const pnlPct = pos.side === 'long' ? priceChangePct * pos.leverage : -priceChangePct * pos.leverage;
    const pnlUsd = pos.marginUsd * pnlPct;
    const payoutUsd = Math.max(0, pos.marginUsd + pnlUsd);

    // Return margin + pnl to USDT
    setHoldings(prev => ({
      ...prev,
      USDT: (prev.USDT || 0) + payoutUsd
    }));

    setPerpPositions(prev => prev.filter(p => p.id !== positionId));

    const tx: Transaction = {
      id: `tx-perpclose-${Date.now()}`,
      type: 'perp_close',
      title: `Closed ${pos.leverage}x ${pos.side.toUpperCase()} ${pos.symbol} (PnL: ${pnlUsd >= 0 ? '+' : ''}$${pnlUsd.toFixed(2)})`,
      timestamp: Date.now(),
      status: 'completed',
      amountUsd: payoutUsd,
      amountInr: payoutUsd * USD_TO_INR_RATE,
      feeUsd: 0.1,
      txHash: '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join(''),
      network: 'Nexis Perps v3 Engine'
    };
    setTransactions(prev => [tx, ...prev]);

    return { success: true, pnlUsd };
  };

  // Prediction Market vote
  const votePredictionMarket = (marketId: string, option: 'yes' | 'no', amountUsd: number) => {
    const currentUsdt = holdings['USDT'] || 0;
    if (amountUsd <= 0) return { success: false, error: 'Enter a valid amount.' };
    if (currentUsdt < amountUsd) return { success: false, error: 'Insufficient USDT balance.' };

    setHoldings(prev => ({
      ...prev,
      USDT: Math.max(0, (prev.USDT || 0) - amountUsd)
    }));

    setPredictionMarkets(prev =>
      prev.map(m => {
        if (m.id !== marketId) return m;
        return {
          ...m,
          userVote: option,
          userAmount: (m.userAmount || 0) + amountUsd,
          yesPoolUsd: option === 'yes' ? m.yesPoolUsd + amountUsd : m.yesPoolUsd,
          noPoolUsd: option === 'no' ? m.noPoolUsd + amountUsd : m.noPoolUsd
        };
      })
    );

    return { success: true };
  };

  // Reset Demo Wallet to starting state (₹100,000)
  const resetDemoWallet = () => {
    setHoldings(INITIAL_HOLDINGS);
    setTransactions(INITIAL_TRANSACTIONS);
    setStakedPositions([
      {
        id: `stake-init-${Date.now()}`,
        tokenSymbol: 'USDT',
        poolName: 'Flexible USDT High Yield',
        amount: 100,
        apy: 8.5,
        durationDays: 'flexible',
        startDate: Date.now(),
        earnedRewards: 0,
        status: 'active'
      }
    ]);
    setPerpPositions([]);
    setPredictionMarkets(INITIAL_PREDICTION_MARKETS);
    localStorage.removeItem(STORAGE_KEYS.HOLDINGS);
    localStorage.removeItem(STORAGE_KEYS.TRANSACTIONS);
    localStorage.removeItem(STORAGE_KEYS.STAKED);
    localStorage.removeItem(STORAGE_KEYS.PERPS);
    localStorage.removeItem(STORAGE_KEYS.PREDICTIONS);
  };

  // Add faucet funds
  const addFaucetFunds = (symbol = 'USDT', amount = 500) => {
    executeDeposit(symbol, amount, 'Demo Faucet Recharge');
  };

  const togglePriceTicking = () => {
    setIsPriceTicking(prev => !prev);
  };

  return (
    <WalletContext.Provider
      value={{
        tokens,
        holdings,
        transactions,
        stakedPositions,
        perpPositions,
        stakingPools: INITIAL_STAKING_POOLS,
        predictionMarkets,
        favorites,
        primaryCurrency,
        setPrimaryCurrency,
        isBalanceHidden,
        toggleBalanceHidden,
        totalBalanceUsd,
        totalBalanceInr,
        portfolioChange24hInr,
        portfolioChange24hPct,
        selectedToken,
        setSelectedToken,
        activeTab,
        setActiveTab,
        tradePresetToken,
        setTradePresetToken,
        tradeModeTab,
        setTradeModeTab,
        toggleFavorite,
        isFavorite,
        getToken,
        executeSwap,
        executeDeposit,
        executeWithdraw,
        executeStake,
        executeUnstake,
        claimStakingRewards,
        openPerpPosition,
        closePerpPosition,
        votePredictionMarket,
        resetDemoWallet,
        addFaucetFunds,
        receiptModalTx,
        setReceiptModalTx,
        isPriceTicking,
        togglePriceTicking,
        theme,
        setTheme,
        effectiveTheme,
        isSettingsOpen,
        setIsSettingsOpen
      }}
    >
      {children}
    </WalletContext.Provider>
  );
};

export const useWallet = () => {
  const context = useContext(WalletContext);
  if (!context) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
};
