export interface Token {
  id: string;
  symbol: string;
  name: string;
  priceUsd: number;
  priceInr: number;
  change24h: number;
  high24h: number;
  low24h: number;
  volume24hUsd: number;
  marketCapUsd: number;
  circulatingSupply: string;
  allTimeHighUsd: number;
  category: 'layer1' | 'defi' | 'meme' | 'ai' | 'gaming';
  sparkline: number[];
  color: string;
  iconBg: string;
  network?: string;
  isFictional?: boolean;
}

export interface WalletHoldings {
  [symbol: string]: number; // e.g. { BTC: 0.0035, ETH: 0.08, ... }
}

export type TransactionType = 'swap' | 'deposit' | 'withdraw' | 'stake' | 'unstake' | 'perp_open' | 'perp_close' | 'bridge';

export interface Transaction {
  id: string;
  type: TransactionType;
  title: string;
  timestamp: number;
  status: 'completed' | 'pending' | 'failed';
  fromSymbol?: string;
  fromAmount?: number;
  toSymbol?: string;
  toAmount?: number;
  amountUsd: number;
  amountInr: number;
  feeUsd: number;
  txHash: string;
  network: string;
  note?: string;
}

export interface StakedPosition {
  id: string;
  tokenSymbol: string;
  poolName: string;
  amount: number;
  apy: number;
  durationDays: number | 'flexible';
  startDate: number;
  earnedRewards: number;
  status: 'active' | 'completed';
}

export interface PerpPosition {
  id: string;
  symbol: string; // e.g. "BTC/USDT"
  side: 'long' | 'short';
  leverage: number;
  entryPrice: number;
  markPrice: number;
  marginUsd: number;
  sizeTokens: number;
  liquidationPrice: number;
  timestamp: number;
}

export interface StakingPool {
  id: string;
  tokenSymbol: string;
  tokenName: string;
  apy: number;
  durationDays: number | 'flexible';
  minStake: number;
  lockType: 'Flexible' | 'Locked 30D' | 'Locked 60D' | 'Locked 90D';
  totalStakedUsd: number;
  riskLevel: 'Low' | 'Medium' | 'High';
}

export interface PredictionMarket {
  id: string;
  title: string;
  category: string;
  endDate: string;
  yesOdds: number;
  noOdds: number;
  yesPoolUsd: number;
  noPoolUsd: number;
  userVote?: 'yes' | 'no';
  userAmount?: number;
}
